---
name: db-check
description: Confirm the SQL Server connection works and give a quick tour of the database
agent: agent
---
Using the `sqlserver` MCP server:

1. Run `SELECT @@SERVERNAME AS server_name, DB_NAME() AS database_name, SUSER_SNAME() AS login_name, @@VERSION AS version;` and show the result.
2. List the schemas and how many tables each has.
3. Show the 10 largest tables by row count (use sys.tables, sys.schemas and sys.partitions).
4. Pick two related tables, show their foreign-key relationship, and run one example JOIN query (TOP 10 rows).
5. Confirm read-only mode: try `UPDATE` on nothing (`UPDATE sys.objects SET name = name WHERE 1 = 0`) and report that it was rejected.

Show every SQL statement you ran.
