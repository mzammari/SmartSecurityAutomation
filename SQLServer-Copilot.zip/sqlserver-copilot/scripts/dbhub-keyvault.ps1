# Optional: use this instead of the VS Code password prompt if policy requires secrets
# to come from Azure Key Vault. It reads the password from Key Vault with your cached
# `az login` and starts DBHub with the same dbhub.toml. Nothing is written to disk.
#
# To use it, change the "sqlserver" server in .vscode/mcp.json to:
#   "command": "powershell.exe",
#   "args": ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "${workspaceFolder}/scripts/dbhub-keyvault.ps1"],
#   "env": { "SQL_USER": "${input:sql-user}" }
#
# Only DBHub may write to stdout (MCP uses it), so all messages here go to stderr.

$ErrorActionPreference = 'Stop'

$vault  = 'YourVaultName'
$secret = 'your-sql-password-secret'
$config = Join-Path $PSScriptRoot '..\config\dbhub.toml'

$sqlPwd = az keyvault secret show --vault-name $vault --name $secret --query value -o tsv 2>$null
if (-not $sqlPwd) {
    [Console]::Error.WriteLine("Key Vault lookup failed. Run 'az login' and restart the MCP server.")
    exit 1
}

$env:SQL_PASSWORD = $sqlPwd
& npx.cmd -y '@bytebase/dbhub@latest' '--transport=stdio' "--config=$config"
