# Copilot → SQL Server (DBHub), workstation setup

Goal: GitHub Copilot Agent mode, using a Claude model, can view tables and run **read-only** queries against a SQL Server database from your workstation.

```
VS Code + Copilot (Agent, Claude)  ──►  DBHub MCP (read-only)  ──►  SQL Server  ──►  your QA database
```

## Before you start: questions for your DBA or IT
1. **Which database?** Start with a QA or test database, not production, and nothing containing PHI unless AI use on it has been approved.
2. **Which login?** Best: a **read-only SQL login** (`db_datareader` + `VIEW DEFINITION`). Also works: your **Windows account over NTLM**. See the auth note below.
3. **Server name, port and database name.** Also find out whether the server requires encryption (TLS).
4. **Is Node.js allowed?** DBHub runs through `npx`. Install Node LTS (22.5+) from Software Center, or ask IT.
5. **Copilot MCP policy.** Your organization may limit MCP servers to an approved list. If so, ask to add `@bytebase/dbhub`.

## Steps

**1. Check you can reach the server** (PowerShell):
```powershell
node -v                                         # v22.5 or later
Test-NetConnection YOUR-SQL-SERVER -Port 1433   # TcpTestSucceeded : True
```

**2. Put this folder somewhere local**, e.g. `C:\Dev\sqlserver-copilot`, and open it in VS Code (**File → Open Folder**).

**3. Edit `config\dbhub.toml`:**
- Set `host` and `database`.
- **SQL login:** nothing else to change.
- **Windows account:** uncomment `authentication = "ntlm"` and set `domain`.
- **Named instance:** set `instanceName`.
- **Certificate or encryption errors:** uncomment `sslmode = "require"`.

**4. Start the server.** Open `.vscode\mcp.json` and click **Start** above `sqlserver`. VS Code asks for your user name and password once and keeps them in its encrypted secret storage. They're never written to a file. The server should then show as **Running**.

**5. Use it in Copilot Chat.** Choose **Agent** mode and a **Claude** model. Check that the `sqlserver` tools (`execute_sql`, `search_objects`) are ticked under the tools icon. Then run:
```
/db-check
```
It confirms which server, database and login you're connected as, gives a quick tour of the tables, runs a sample JOIN, and proves that writes are rejected.

**6. Ask real questions**, for example:
- *"What tables hold employee scheduling data? Show their columns and relationships."*
- *"Write a query joining X, Y and Z to show …, TOP 50, and explain it."*
- *"Give me 5 rows of test data that match these conditions: …"*

## Authentication: what works
| Login type | Works? | Notes |
|---|---|---|
| SQL login (read-only service account) | ✅ | Simplest and safest. Protection comes from both DBHub and the login's permissions |
| Windows / domain account via NTLM | ✅ | Needs your password (prompted once and stored securely). Copilot gets the same rights you have, limited by DBHub's read-only filter |
| Windows **integrated** auth (no password, like SSMS) | ❌ | Not supported by DBHub's Node.js driver. For that, you'd need a .NET-based MCP server using `Integrated Security=true` |
| Azure SQL + Entra ID | ✅ | Use `authentication = "azure-active-directory-access-token"` with `az login`. This extra option needs the `@azure/identity` package available |

**If policy requires Key Vault** rather than the VS Code prompt, use `scripts\dbhub-keyvault.ps1`. The instructions are at the top of the script.

## Troubleshooting
| Symptom | Fix |
|---|---|
| Server won't start or shows red | **View → Output**, choose `sqlserver` in the dropdown, and read the error |
| `Login failed for user` | Wrong user or password. To re-enter them, run **MCP: Reset Cached Inputs** from the Command Palette |
| `Failed to connect … ESOCKET` / timeout | Firewall, VPN, wrong port, or a named instance without `instanceName` |
| Certificate / `self-signed` errors | Set `sslmode = "require"` |
| `Read-only mode is enabled` | Working as intended. Copilot tried something other than SELECT, WITH or EXPLAIN (including `DECLARE`) |
| `spawn npx ENOENT` | Set `"command": "cmd"` and put `"/c", "npx",` at the start of `args` |
| `ERROR: --readonly flag is no longer supported` | Current DBHub sets read-only in `dbhub.toml`, not on the command line |
