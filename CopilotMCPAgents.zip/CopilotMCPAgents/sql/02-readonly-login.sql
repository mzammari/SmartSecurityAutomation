/* =====================================================================
   Read-only login for the Database agent (DBHub)
   Requires "SQL Server and Windows Authentication mode" (restart the
   SQL Server service after changing it). Change the password first.
   If you already created claude_reader for the AdventureWorks kit,
   skip the CREATE LOGIN block and run the rest.
   ===================================================================== */
USE master;
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'claude_reader')
    CREATE LOGIN claude_reader WITH PASSWORD = N'ChangeMe_Str0ngPwd', CHECK_POLICY = ON;
GO

USE rahulshettyacademy;
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'claude_reader')
    CREATE USER claude_reader FOR LOGIN claude_reader;
GO
ALTER ROLE db_datareader ADD MEMBER claude_reader;
GRANT VIEW DEFINITION TO claude_reader;
DENY INSERT, UPDATE, DELETE, EXECUTE TO claude_reader;
GO
