# Workspace instructions for GitHub Copilot

This workspace is a **QA automation lab** built on MCP servers. It is the Copilot version of the "LLM-MCP (AI Agent)" course, which originally used Claude Desktop.

- MCP servers are defined in `.vscode/mcp.json`: `playwright`, `database` (DBHub, read-only SQL Server/MySQL), `excel`, `rest-api` and `filesystem` (limited to `data/`).
- There is one custom agent per server in `.github/agents/`, plus the **QA Orchestrator** for end-to-end flows. Ready-made labs are in `.github/prompts/`; run them with `/01-explore-db`, `/02-register-users-from-db`, and so on.
- All data is demo data. Never enter real personal data, PHI or real credentials into any site, file or API.
- The database connection is read-only. Don't try to modify data; offer a reviewable script instead.
- Test data and results live in `data/`. The Excel tools need absolute paths.
- When writing test code, the team stack is C#/.NET with NUnit and Microsoft.Playwright.
