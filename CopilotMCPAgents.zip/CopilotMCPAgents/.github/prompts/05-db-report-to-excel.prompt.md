---
description: "Course lab 5 – DB → Excel (+ file): build an orders report workbook and a CSV copy"
agent: QA Orchestrator
---
1. **DB Analyst:** write one query that returns, for each customer: name, city, age, total orders, first order date, last order date, and a comma-separated list of the companies they ordered from. Include customers with no orders. Sort by total orders descending.
2. **Excel Agent:** write the results to a new sheet named `OrdersReport` in `data/newdata.xlsx`. Format it as an Excel table with bold headers and dates formatted `yyyy-mm-dd`.
3. **File Manager:** save the same results as `data/orders-report.csv`.
4. Tell me the sheet range and file path, and show the SQL used.
