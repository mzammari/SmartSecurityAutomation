---
description: "Course lab 3 – Excel → UI: log in with every credential in the workbook and verify the result"
agent: QA Orchestrator
---
1. **Excel Agent:** read all rows from Sheet1 of `data/newdata.xlsx`. Column A is the Email and column B is the password.
2. **UI Tester:** for each row, open https://rahulshettyacademy.com/client/#/auth/login, log in, and verify that login succeeded (the products/dashboard page loads). Then sign out.
   - Also run one **negative test**: the first user's email with the password `Wrong@123`. Verify that an error message appears.
   - Take a screenshot of each result.
3. **Excel Agent:** write each row's result (PASS/FAIL plus the message shown) to the first empty column after the existing data (column E if Lab 2 has run), with the header `LoginResult`. Don't overwrite columns A–D.
4. Give me the report table.
