---
description: "Course lab 2 – DB → UI: register every user from the database on the Let's Shop site, then save their logins to Excel"
agent: QA Orchestrator
argument-hint: "Optional: how many users (default: all)"
---
Run this end-to-end flow:

1. **DB Analyst:** get ${input:count:all} users from RegistrationDetails joined with UserNames (id, first name, last name, email, phone, occupation, gender, 18+ flag, password).

2. **UI Tester:** for each user, open https://rahulshettyacademy.com/client/#/auth/register and fill the registration form from that row:
   - Map each column to the matching field: first/last name, email, phone, occupation dropdown, gender radio, password and confirm password, and the "18 or older" checkbox only when the flag is true.
   - Submit, then confirm the success message.
   - If the site rejects the password as too weak, use `<FirstName>@Test123`.
   - If the email is already registered, retry once with `+<yyyyMMddHHmm>` added before the @.
   - If the occupation isn't in the dropdown, mark the user BLOCKED and move on.
   - Record the exact email and password actually used.

3. **Excel Agent:** in Sheet1 of `data/newdata.xlsx`, keep the existing headers (A = `Email`, B = `password`) and add C = `id_number` and D = `Result`. Then append one row per registered user, after the last used row, with the email and password actually used.

4. Give me the final report table and point me to the screenshots.
