---
description: "Course lab 1 – explore the course database and run the join queries"
agent: DB Analyst
---
Explore the database:

1. List every table with its columns, primary keys and foreign keys, and draw a small ASCII diagram of how they relate.
2. Show the names of customers who have placed at least one order.
3. Show the companies that have placed more than one order, with their order counts.
4. Join RegistrationDetails with UserNames and show id, first name, last name, email, phone, occupation, gender and the 18+ flag for every user.
5. Show, for each city, the number of customers, the number of orders and the most recent order date. Include cities with zero orders.

Show the SQL for each step.
