---
description: "Course lab 4 – API: log in via REST, create an order with the token, then verify in the UI"
agent: API Tester
argument-hint: "Login email for your practice account"
---
Replay the course's **EcomBasic** Postman collection with the rest-api tools:

1. **Login:** POST `/api/ecom/auth/login` with `userEmail` = ${input:email:your practice account email}. Ask me for the password; don't guess it. Assert status 200 and that `token` and `userId` are present. Save both.
2. **Create order:** POST `/api/ecom/order/create-order` with the header `Authorization: <token>` and body `{"orders":[{"country":"India","productOrderedId":"67a8dde5c0d3e6622a297cc8"}]}`. Assert success and save the returned order id(s).
3. **Negative tests:** create-order with no Authorization header, then login with a wrong password. Confirm both fail with an appropriate status and message.
4. Report the results table and the extracted variables (token masked).

When you're done, offer the **"Verify in the UI"** handoff so the UI Tester can confirm the order appears on the site's Orders page.
