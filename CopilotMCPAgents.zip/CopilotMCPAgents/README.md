# MCP AI Agents in GitHub Copilot (VS Code)

This is the Copilot version of the **LLM-MCP (AI Agent)** course, which originally used Claude Desktop. You get the same five MCP servers, one **custom Copilot agent per server**, an **orchestrator** for end-to-end flows, and the course labs as one-click prompt files. There's no Claude Desktop, and you don't need to open a terminal.

```
VS Code + GitHub Copilot (Agent mode, Claude model)
│
├── QA Orchestrator ──delegates──┐
│                                ▼
├── UI Tester ───── playwright   ─► browser (Let's Shop site)
├── DB Analyst ──── database     ─► DBHub ─► SQL Server (read-only)
├── Excel Agent ─── excel        ─► data/newdata.xlsx
├── API Tester ──── rest-api     ─► rahulshettyacademy.com/api
└── File Manager ── filesystem   ─► data/ folder only
```

## What changed from the course

| Course (Claude Desktop) | This workspace (Copilot) | Why |
|---|---|---|
| `claude_desktop_config.json` with `mcpServers` | `.vscode/mcp.json` with `servers` | VS Code's format |
| `mysql_mcp_server` run with Python + uv | **DBHub** (`@bytebase/dbhub`) | Node only, so one runtime instead of two. Works with SQL Server *and* MySQL, and is read-only by config |
| Excel server through the Smithery CLI with an API key | `npx @negokaz/excel-mcp-server` | Same server, no key or third-party account needed |
| filesystem limited to a Mac folder | limited to `${workspaceFolder}/data` | Portable; only the lab data is reachable |
| One chat with every tool | **One agent per server**, plus an orchestrator | Each agent sees only its own tools, so it makes fewer wrong tool choices and it's clearer who does what |
| MySQL `Untitled.sql` | `sql/01-course-db-sqlserver.sql` | T-SQL port with identical data |

## Workspace layout
```
.vscode/mcp.json                  MCP servers (playwright, database, excel, rest-api, filesystem)
.github/agents/*.agent.md         6 custom agents
.github/prompts/*.prompt.md       Course labs 1–5 as slash commands
.github/copilot-instructions.md   Rules every agent follows
config/dbhub.toml                 DB connection + read-only settings
sql/                              Course DB for SQL Server + read-only login
data/newdata.xlsx                 Course workbook (Excel and filesystem agents work here)
```

---

## Requirements, and what to ask IT for

| Need | Why | Terminal needed? |
|---|---|---|
| **VS Code + GitHub Copilot** (Agent mode enabled) | Runs the agents | No |
| **Node.js LTS 20+** installed | `npx` runs every MCP server | **No.** VS Code starts the servers itself. Node just has to be installed (it's a normal Windows installer). |
| Access to **registry.npmjs.org** (directly or through the corporate proxy) | `npx` downloads the servers the first time | No |
| Copilot **MCP policy** allows these servers | Admins can limit MCP to an approved registry | No |
| **SQL Server** + **SSMS** (local or a dev server) | Course database | No, SSMS is a GUI |

If Node.js can't be installed, the MCP servers can't run on your workstation. Two fallbacks:
1. Copilot has **built-in** browser (`#browser`) and web-fetch (`#web/fetch`) tools that need no Node. They cover part of the UI and API labs.
2. Ask IT to allowlist Node.js LTS plus these five npm packages: `@playwright/mcp`, `@bytebase/dbhub`, `@negokaz/excel-mcp-server`, `dkmaker-mcp-rest-api`, `@modelcontextprotocol/server-filesystem`.

---

## Setup (about 15 minutes)

1. **Unzip** to `C:\CopilotMCPAgents` and open the folder in VS Code (**File → Open Folder**). Trust the workspace when asked.
2. **Create the course database.** In SSMS, run `sql/01-course-db-sqlserver.sql`, then change the password in `sql/02-readonly-login.sql` and run it. This needs mixed-mode authentication; see the comment at the top of the file.
3. **Edit `config/dbhub.toml`.** Put your password and server in the `dsn` line. For a named instance, append `&instanceName=SQLEXPRESS`.
4. **Start the MCP servers.** Open `.vscode/mcp.json` and click **Start** above each server, or just send a chat message and they auto-start.
   - The first start takes a minute while `npx` downloads the packages.
   - Check the status in the **Extensions** view under **MCP SERVERS**. Each server should show as running with its tool count: playwright 25, database 2, excel 6, rest-api 1, filesystem 14.
5. **Open Copilot Chat.** Pick a **Claude** model. In the agent dropdown (where it says *Agent*), you'll see **QA Orchestrator, UI Tester, DB Analyst, Excel Agent, API Tester, File Manager**.

## Running the course labs

In the chat box, type `/` and pick a lab. Each lab switches to the right agent automatically.

| Command | Agent | What it does |
|---|---|---|
| `/01-explore-db` | DB Analyst | Maps the schema and runs the course's join and aggregate queries |
| `/02-register-users-from-db` | QA Orchestrator | DB → registration form on the site → saves logins to Excel |
| `/03-login-from-excel` | QA Orchestrator | Excel → logs in each user and writes PASS/FAIL back to Excel |
| `/04-api-login-create-order` | API Tester | Replays the EcomBasic Postman flow: login → token → create order |
| `/05-db-report-to-excel` | QA Orchestrator | SQL report → formatted Excel sheet plus a CSV |

You can also pick any agent from the dropdown and just talk to it, e.g. **UI Tester**: *"Open the Let's Shop login page and check that a wrong password shows an error."*

**Handoff buttons.** After a specialist finishes, buttons like **"Save results to Excel"** or **"Verify against the database"** appear. Click one to pass the work to the next agent. This is the manual way to chain steps; the Orchestrator does it automatically.

**Approvals.** Copilot asks before each tool call. For a smooth run, choose **Allow in this session**, or **Always allow** for tools you trust (the read-only DB tools, Excel reads).

---

## Things to know
- **The Let's Shop site is shared.** Other students have probably registered the same emails already, so expect "already exists" errors. Lab 2 handles this by retrying with a unique `+timestamp` email. The site may also reject the DB's `12345` passwords as too weak, and may not offer every occupation in the data (e.g. *Teacher*, *Artist*). The agents report these as findings; they don't invent values.
- **API credentials.** Use your own practice account for Lab 4. The course's Postman collection contains the instructor's login, which isn't included here.
- **Excel file locks.** Close `newdata.xlsx` in Excel before the Excel Agent writes to it.
- **Orchestrator delegation.** It runs the specialists as subagents. If your VS Code or Copilot version doesn't allow custom agents as subagents yet, the Orchestrator still has every tool and runs the steps itself. Or run the specialists one by one with the handoff buttons.
- **No PHI or real data.** These are demo sites and databases only; keep it that way on a work machine.

## Troubleshooting
| Symptom | Fix |
|---|---|
| A server shows an error or 0 tools | **View → Output**, choose **MCP: \<server\>** in the dropdown to read the log |
| `spawn npx ENOENT` | Node.js isn't installed or isn't on PATH. Restart VS Code after installing Node |
| Servers never appear in the tools list | Your organization's Copilot MCP policy may be "Registry only". Ask the Copilot admin |
| `ERROR: --readonly flag is no longer supported` | Don't add `--readonly`; read-only mode is set in `config/dbhub.toml` |
| `Login failed for user 'claude_reader'` | Mixed-mode auth is off (restart the service after changing it), or the password needs URL-encoding |
| `Read-only mode is enabled…` | Working as intended: the agent tried something other than SELECT or WITH |
| Excel write fails | Close the workbook in Excel. Check the agent used an absolute path |
| npx download fails behind the corporate proxy | Ask IT for npm proxy settings (`npm config set proxy ...`). This is normally a one-time machine setting IT can push |
