﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using WebUiAutomation;
using WebUiTests.Utilities;

namespace WebUiTests.Page.Objects
{
    public class PingPage
    {
        private readonly WebDriverWait _waitDriver;
        private readonly Browser _browser;

        public PingPage(Browser browser)
        {
            _browser = browser;
            _waitDriver = new WebDriverWait(_browser.Driver, TimeSpan.FromSeconds(30));
        }

        #region Page Objects
        public HpgElement EmailInput => new(_waitDriver.Until(d => d.FindElement(By.Id("identifierInput"))), "Email Input");
        public HpgElement NextButton => new(_waitDriver.Until(d => d.FindElement(By.CssSelector("#postButton>a"))), "Next Button");
        #endregion Page Objects

        #region Page Actions
        public void LoginThruPing(string username, string password)
        {
            EmailInput.Type($"{username}@hca.corpad.net");
            var networkInterceptor = _browser.Driver.GetNetworkInterceptor(username, password, "medcity.net");
            networkInterceptor.StartMonitoring();

            NextButton.Click();

            networkInterceptor.StopMonitoring();
        }
        #endregion Page Actions

        #region Validations

        #endregion Validations

    }
}