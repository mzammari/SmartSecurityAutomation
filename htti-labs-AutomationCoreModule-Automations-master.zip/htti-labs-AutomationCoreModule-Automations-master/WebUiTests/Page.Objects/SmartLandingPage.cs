﻿using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using WebUiAutomation;
using System;
using AutomationCoreLite.Reporting;

namespace WebUiTests.Page.Objects
{
    public class SmartLandingPage
    {
        private readonly WebDriverWait _waitDriver;
        private readonly Browser _browser;

        public SmartLandingPage(Browser browser)
        {
            _browser = browser;
            _waitDriver = new WebDriverWait(_browser.Driver, TimeSpan.FromSeconds(30));
        }

        #region Page Objects
        public HpgElement SmartLogo => new(_waitDriver.Until(d => d.FindElement(By.CssSelector("img.smart_logo"))), "Smart Logo");
        public HpgElement ProcurementTile => new(_waitDriver.Until(d => d.FindElement(By.Id("Procurement"))), "Procurement Tile");
        public HpgElement AdminTile => new(_waitDriver.Until(d => d.FindElement(By.Id("Admin"))), "Admin Tile");
        #endregion Page Objects

        #region Page Actions

        #endregion Page Actions

        #region Validations
        public void ValidateLandingPage()
        {
            Steps.AddTestStep("Validate Landing Page web elements exists.", "Web Elementst should be shown.");

            //Validate Elements
            HPGWarn.True(SmartLogo.Exists(), "Smart Logo is displayed on the Landing Page.");
            HPGWarn.True(ProcurementTile.Exists(), "Procurement Tile is displayed on the Landing Page.");
            HPGWarn.True(AdminTile.Exists(), "Admin Tile is displayed on the Landing Page.");

            //Take Screenshot
            Steps.AddScreenShot(_browser.TakeBase64Screenshot());
        }
        #endregion Validations

    }
}