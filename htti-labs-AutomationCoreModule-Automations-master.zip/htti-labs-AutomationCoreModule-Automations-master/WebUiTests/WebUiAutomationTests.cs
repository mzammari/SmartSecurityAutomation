using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using WebUiAutomation;
using WebUiTests.Page.Objects;

[assembly: Parallelize(Workers = 0, Scope = ExecutionScope.MethodLevel)]

namespace WebUiTests
{
    [TestClass]
    public class WebUiAutomationTests
    {
        private Browser browser;
        private string password;

        [TestInitialize]
        public void Setup()
        {
            browser = new Browser("http://localhost:5555");
            password = Environment.GetEnvironmentVariable("Password") ?? throw new InvalidOperationException("Password environment variable is not set.");


        }

        [TestCleanup]
        public void TearDown()
        {            
            browser.Close();
        }

        [TestMethod]
        public void SeleniumGridNonAuthenticatedTest()
        {
            var ranOnGrid = true;
            
            browser.OpenNewBrowser("chrome", grid: ranOnGrid);
            browser.Navigate("https://www.google.com/");
            var feelingLuckyButton = browser.Driver.FindElement(By.Id("gbqfbb"));
            Assert.AreEqual("I'm Feeling Lucky", feelingLuckyButton.GetAttribute("value").ToString());
        }

        //todo: need to update test to use a different application.
        [TestMethod]
        public void SeleniumGridTest()
        {
            string url      = $"https://qa-smart.healthtrustpg.com/";

            var chromeOption = new ChromeOptions();
            chromeOption.AddArguments("--remote-allow-origins=*");

            var ranOnGrid = true;
            browser.OpenNewBrowser(grid: ranOnGrid, userDriverOptions: chromeOption);            

            var handler = new NetworkAuthenticationHandler()
            {
                UriMatcher  = _ => true,
                Credentials = new PasswordCredentials("HTNASVCTSTAUT01", password)
            };
            INetwork networkInterceptor = browser.Driver.Manage().Network;
            networkInterceptor.AddAuthenticationHandler(handler);
            networkInterceptor.StartMonitoring().Wait();
            browser.Driver.Navigate().GoToUrl(url);
            networkInterceptor.StopMonitoring().Wait();

            Assert.AreEqual(url, browser.Url);
            Thread.Sleep(1500);
            if (ranOnGrid) Assert.IsNotNull(browser.Node);

            Thread.Sleep(5000);

            Assert.AreEqual($"{url}", browser.Url);
            Assert.IsTrue(browser.Driver.FindElement(By.Id("Procurement")).Displayed);

            var smartLandingPage = new SmartLandingPage(browser);
            smartLandingPage.ValidateLandingPage();
            smartLandingPage.ProcurementTile.Click();

            browser.TakeScreenshot(
                $"\\\\Hca.corpad.net\\DPT02\\SCPD\\Automation\\Screenshots\\AutomationCoreModule\\Test_{DateTime.Now:mmddyyyyhhmmss}.jpeg");
        }

        [TestMethod]
        public void SeleniumGridTestCertificates()
        {
            string userName = "HTNASVCTSTAUT01";
            string url      = $"https://qa-smart.healthtrustpg.com";

            var ranOnGrid = false;
            browser.OpenNewBrowser("chrome",grid: ranOnGrid);
            _ = browser.EnterCreds(userName, password);

            browser.Navigate(url);

            Thread.Sleep(1500);
            Assert.AreEqual($"{url}/", browser.Url);
            if (ranOnGrid) Assert.IsNotNull(browser.Node);

            browser.TakeScreenshot(
                $"\\\\Hca.corpad.net\\DPT02\\SCPD\\Automation\\Screenshots\\AutomationCoreModule\\Test_{DateTime.Now:mmddyyyyhhmmss}.jpeg");
        }

        [TestMethod]
        public void DriverOptions()
        {
            string userName = "HTNASVCTSTAUT01";
            string url      = $"https://qa-smart.healthtrustpg.com";

            ChromeOptions options = new ChromeOptions();
            options.AcceptInsecureCertificates = true;            
            
            var ranOnGrid = false;
            browser.OpenNewBrowser("chrome", grid: ranOnGrid, userDriverOptions: options);
            _ = browser.EnterCreds(userName, password, "healthtrustpg.com");
            Thread.Sleep(500);
            browser.Navigate(url);

            Thread.Sleep(1500);
            Assert.AreEqual($"{url}/", browser.Url);
            Assert.IsTrue(browser.Driver.FindElement(By.Id("Procurement")).Displayed);
        }

        
    }
}