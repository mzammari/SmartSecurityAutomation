﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutomationCoreLite.Reporting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationCoreLite.Reporting.HPGWarnTest
{
    [TestClass()]
    public class HPGWarnHPGWarnTests
    {
        [TestMethod()]
        public void AreEqualTest()
        {
            HPGWarn.AreEqual("1", "1");
            Assert.IsFalse(HPGWarn.Warnings.Any());

            HPGWarn.AreEqual("1","1",field: "Test Field");

            HPGWarn.AreEqual("1", "2");
            Assert.IsTrue(HPGWarn.Warnings.Any());
            Assert.AreEqual("'2' does not match the expected value of '1'. VALUES WERE NOT EQUAL!", HPGWarn.Warnings.FirstOrDefault().Message);
        }

        [TestMethod()]
        public void ClearWarnings()
        {
            HPGWarn.AreEqual("1", "2");
            Assert.IsTrue(HPGWarn.Warnings.Any());

            HPGWarn.Warnings.Clear();

            Assert.IsTrue(!HPGWarn.Warnings.Any());
        }

        [TestMethod]
        public void AddListOfWarnings()
        {
            var list = new List<string>()
            {
                "test 1",
                "Test 2",
                "test 3"
            };

            HPGWarn.WarnRange(list);

            Assert.AreEqual(3, HPGWarn.Warnings.Count);
        }
    }
}