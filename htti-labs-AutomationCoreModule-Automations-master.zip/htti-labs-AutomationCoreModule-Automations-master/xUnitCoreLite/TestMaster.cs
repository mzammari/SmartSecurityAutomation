﻿using AutomationCoreLite.Reporting;
using Xunit.Abstractions;

namespace xUnitCoreLite;

public class TestMaster : IDisposable
{
    protected readonly ITestOutputHelper output;
    protected TestMaster(ITestOutputHelper output)
    {
        this.output = output;
        Steps.BeginTestSteps();
    }

    public void Dispose()
    {
        Steps.EndTestSteps();
        output.WriteLine(Steps.StepsOutput);
    }
}