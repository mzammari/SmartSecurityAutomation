﻿using AutomationCoreLite.Reporting;
using Xunit.Abstractions;

namespace xUnitCoreLite;

[Collection("SequentialExecution")]
public class StepsParallel : TestMaster
{
    public StepsParallel(ITestOutputHelper output) : base(output)
    { }

    [Fact]
    public void Test3()
    {
        const int maxLoop = 10;
        var       counter = 0;
        var       rnd     = new Random();
        do
        {
            var sleepTime = rnd.Next(0, 1000);
            Steps.AddTestStep($"Counter Step: {counter}", "Test3");
            Thread.Sleep(sleepTime);
            counter++;
        } while (counter < maxLoop);
    }

    [Fact]
    public void Test4()
    {
        const int maxLoop = 10;
        var       counter = 0;
        var       rnd     = new Random();
        do
        {
            var sleepTime = rnd.Next(0, 1000);
            Steps.AddTestStep($"Counter Step: {counter}", "Test4");
            Thread.Sleep(sleepTime);
            counter++;
        } while (counter < maxLoop);
    }

}