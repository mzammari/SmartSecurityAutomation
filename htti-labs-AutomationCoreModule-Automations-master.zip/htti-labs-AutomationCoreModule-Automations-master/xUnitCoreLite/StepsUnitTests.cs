using AutomationCoreLite.Reporting;
using Xunit.Abstractions;

namespace xUnitCoreLite
{
    [Collection("SequentialExecution")]
    public class StepsUnitTests : TestMaster
    {
        public StepsUnitTests(ITestOutputHelper output) : base(output)
        {
            
        }

        
        [Fact]
        public void Test1()
        {
            const int maxLoop = 10;
            var       counter = 0;
            var       rnd     = new Random();
            do
            {
                var sleepTime = rnd.Next(0,1000);
                Steps.AddTestStep($"Counter Step: {counter}", "Test1");
                Thread.Sleep(sleepTime);
                counter++;
            } while (counter < maxLoop);
            
        }

        [Fact]
        public void Test2()
        {
            const int maxLoop = 10;
            var       counter = 0;
            var       rnd     = new Random();
            do
            {
                var sleepTime = rnd.Next(0, 1000);
                Steps.AddTestStep($"Counter Step: {counter}", "Test2");
                Thread.Sleep(sleepTime);
                counter++;
            } while (counter < maxLoop);
        }
    }
}