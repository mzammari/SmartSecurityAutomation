# Automation Core Web

## Overview
The WebUiAutomation project is designed to automate web UI testing for various web applications. It leverages modern automation tools and frameworks to ensure efficient and reliable test execution.

## Browser Class
The Browser class allows you to choose the Browser type to test with, navigate to a specific URL, take screenshots, etc. Below are a examples of the methods you can use.

### OpenNewBrowser
The open new browser method will allow you to choose which browser to test in, on your local machine or 'Grid', and driver options. Note: Please reference [Selenium](https://www.selenium.dev/documentation/webdriver/drivers/options/) documentation for driver options. If you pass in no arguments, then it will default to the Chrome browser on your local machine.

Current browser options are 'chrome' (Default), 'edge', and 'firefox'.

#### Public Attributes
- `Driver`: This is the Evinced WebDriver that is used to control the browser. (Note: This WebDriver is specific to the Evinced framework and may differ from standard Selenium WebDriver.Version 1.3.5)
- `BaseDriver`: This is the base Selenium WebDriver that is used to control the browser. (Note: This WebDriver is standard Selenium WebDriver and can be used for other purposes as well.)
- `Hub`: This is the Selenium Grid hub URL. 
- `Node`: This is the Selenium Grid node URL. 

#### Sample
```C# 
//Instantiate 
//The argument is for selenium grid url. Can pass in blank, but it will not run on the grid.
var browser = new Browser(""); 

//Default 
browser.OpenNewBrowser();

//Choosing browser
browser.OpenNewBrowser("edge");

//Running on the grid
browser.OpenNewBrowser("edge",true);

//Driver Options
var chromeOption = new ChromeOptions();
chromeOption.AddArguments("--remote-allow-origins=*");
browser.OpenNewBrowser("edge",true,chromeOption);
```
### Close
The Close method will close the browser.

#### Example
```C#
browser.Close();
```

### Navigate
The Navigate method will all you to go to the specified URL you pass in.


#### Example
```C#
var browser = new Browser("");
browser.OpenNewBrowser();
browser.Navigate("www.google.com");
```

### EnterCreds
The EnterCreds method allows you to automatically enter in user credentials. It takes in the following arguments:
- Username
- Password
- Domain: The domain is the URL domain. Example: www.smart.healthtrustpg.com is the URL. The domain would be healthtrustpg.com.

You will want to implement this before the Naviate method.

#### Example
```C#
_ = browser.EnterCreds(userName, password, "healthtrustpg.com");
```

### TakeScreenshot
The TakeScreenshot method will allow you to capture a screenshot of the browser. The argument it take is the path location with the file name and format type.

#### Example
```C#
browser.TakeScreenshot("C:\\pictures\\sample.jpg");
```

### TakeBase64Screenshot (Version 1.1.3)
The TakeBase64Screenshot method will allow you to capture a screenshot of the browser and returns a base 64 encoded string. 

#### Example
```C#
var encodedScreenshot = browser.TakeBase64Screenshot();
```

## HPG Element Class
The HPGElement class is a wrapper around the Selenium WebElement class, providing additional functionality specific to HCA HealthTrust's web applications. It includes methods for interacting with web elements in a more intuitive way.

#### Public Attributes
- `Element`: The underlying Selenium WebElement.
- `Driver`: The underlying Selenium WebDriver.
- `Identifier`: The identifier is a descriptive name for the element.
- `Text`: The text content of the element.

#### Example
```C#
var element = new HPGElement(webElement);
element.Click();
```
There are are several different instanciations of the HPGElement class. Below are some examples of how to instantiate the HPGElement class.
```C#
//Instantiate with a WebElement
var element = new HPGElement(webElement);

//Instantiate with a WebElement and a descriptive identifier
var element = new HPGElement(webElement, "Descriptive Identifier"); 

//Instantiate with a WebElement, a descriptive identifier, and a driver 
//(Note: This is the new due to Evinced WebDriver. The Evinced webDriver does not allow to 
//go to the native Selenium WebDriver methods, so you need to pass in the driver. Version 1.4.0 or later)
var element = new HPGElement(webElement, "Descriptive Identifier", driver);
```
### HPG Element Methods
The HPGElement class provides several methods for interacting with web elements. Below are some of the commonly used methods:
- `Click()`: Clicks the element.
- `Type(string text)`: Types the specified text into the element.
- `Exists()`: Checks if the element exists on the page.
- `ClickOffset(int x, int y)`: Clicks the element at the specified offset.
- `ScrollIntoView()`: Scrolls the element into view.

For more capabilities, you can go to the native Selenium WebElement methods by using the `Element` property of the HPGElement class. More information can be found in the [Selenium documentation](https://www.selenium.dev/documentation/webdriver/elements).

## ADA Evinced (version 1.4.0 or later)
The Evinced ADA (Automated Digital Accessibility) solution is designed to help organizations ensure their web applications are accessible to all users, including those with disabilities. It provides tools and features to identify and remediate accessibility issues in real-time, making it easier for developers to create compliant applications. Here are the steps to get started with Evinced:

1. **Upgrade to the AutomatioCoreWebUi 1.4.0 or later**: Ensure you have the latest AutomationCoreWebUI Nuget Package installed and configured in your project. This is essential for running accessibility tests.
2. **Get the Evinced Secret key and API key**: You will need to obtain the Evinced secret key and API key from your Evinced account. These keys are required to authenticate your requests to the Evinced API.
3. **Configure Evinced in your main test setup**: In your main test setup, you need to configure the Evinced settings. This includes setting the Evinced secret key and API key, as well as any other necessary configurations.
    ```C#
    //Evinced Setup
    EvincedSDK.SetOfflineCredentials(GlobalTestVariables.Evinced_Service_ID, GlobalTestVariables.Evinced_Secret_Key);
    Global.Config.EnableScreenshots = true;
    EvincedSDK.UploadToPlatform = true;
    EvincedSDK.TestRunInfo().CustomLabel("Team", "<Area of Testing>"); // Example: "Team", "Supply Chain"
    ```
4. **Start the Evinced Engine**: Add the following code after your automation opens the browser. This will start the Evinced engine and begin monitoring for accessibility issues.
    ```C#
    //Start Evinced Engine
    Browser.Driver.SetTestInfo(GlobalTestVariables.TestName, "SMART APP UI Tests");
    Browser.Driver.EvStart();
    ```
5. **Tear Down**: You will need to add the following method to your tear down code. This will stop the Evinced engine and generate the ADA report.
    ```C#
    /// <summary>
    /// Tear down the browser and take a screen shot.
    /// </summary>
    private void BrowserTearDown()
    {
        Steps.AddScreenShot(Browser.TakeBase64Screenshot());

        try
        {
            IReport report = Browser.Driver.EvStop(PlatformUpload.Enabled);

            var AdaJsonFile = EvincedSDK.EvSaveFile($"{GlobalTestVariables.ScreenShotFileLocation}\\{GlobalTestVariables.TestName}_{DateTime.Now:MMddyyyyhhmmssss}_ADA", report, FileFormat.JSON);
            var adaHtmlFile = EvincedSDK.EvSaveFile($"{GlobalTestVariables.ScreenShotFileLocation}\\{GlobalTestVariables.TestName}_{DateTime.Now:MMddyyyyhhmmssss}_ADA", report, FileFormat.HTML, Browser.Driver);

            GlobalTestVariables.RallyScreenShots.Add(AdaJsonFile);
            GlobalTestVariables.RallyScreenShots.Add(adaHtmlFile);
            
        }
        catch (Exception e)
        {
            ConsoleOut.WriteReport($"Error Generating ADA Report: {e.Message}");
        }
        finally
        {
            VmName = Browser.Node;
            Browser.Close();
        }
    }
    ```
    To call this method from your tear down method, you can use the following:
    ```C#
    //If a Browser was opened i.e. a UI test, then take a screen shot and close the browser.
    if (Browser.Driver != null)
        BrowserTearDown();
    ```