﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using AutomationCoreLite.Reporting;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using System.Threading;

namespace WebUiAutomation
{
    /// <summary>
    /// Provides browser automation functionality, including driver management, navigation, authentication, and screenshots.
    /// </summary>
    public class Browser
    {
        /// <summary>
        /// Gets or sets the base Selenium WebDriver instance.
        /// </summary>
        public IWebDriver Driver;       

        /// <summary>
        /// Gets or sets the Selenium Grid hub URL.
        /// </summary>
        public string Hub;

        /// <summary>
        /// Gets or sets the Selenium Grid node URI where the session is running.
        /// </summary>
        public string Node;

        /// <summary>
        /// Gets the current URL of the browser.
        /// </summary>
        public string Url => Driver.Url;

        /// <summary>
        /// Initializes a new instance of the <see cref="Browser"/> class with the specified Selenium Grid hub URL.
        /// </summary>
        /// <param name="hub">The Selenium Grid hub URL.</param>
        public Browser(string hub)
        {
            Hub = hub;
        }

        /// <summary>
        /// Opens a new browser instance of the specified type, either locally or on a Selenium Grid.
        /// </summary>
        /// <param name="browserType">The browser type ("chrome", "firefox", or "edge").</param>
        /// <param name="grid">Whether to use Selenium Grid.</param>
        /// <param name="userDriverOptions">Optional driver options for the browser.</param>
        public void OpenNewBrowser(string browserType = "chrome", bool grid = false, DriverOptions userDriverOptions = null)
        {
            if (grid)
            {
                // Use provided driver options or create new options based on browser type
                DriverOptions caps = userDriverOptions ?? browserType.ToLower() switch
                {
                    "edge" => new EdgeOptions(),
                    "firefox" => new FirefoxOptions(),
                    _ => new ChromeOptions()
                };

                // Accept insecure certificates for grid sessions
                caps.AcceptInsecureCertificates = true;
                Driver = new RemoteWebDriver(new Uri($"{Hub}/wd/hub"), caps);

                Thread.Sleep(2000); // Wait for the session to initialize

                // Asynchronously retrieve the VM node name (fire and forget)
                _ = GetVMNodeName();
                ConsoleOut.WriteReport($"Running on VM: '{Node}'.");
            }
            else
            {
                try
                {
                    // Use current directory for driver binaries
                    //string currentDir = Directory.GetCurrentDirectory();
                    Driver = browserType.ToLower() switch
                    {
                        "firefox" => userDriverOptions == null
                            ? new FirefoxDriver()
                            : new FirefoxDriver((FirefoxOptions)userDriverOptions),
                        "edge" => userDriverOptions == null
                            ? new EdgeDriver()
                            : new EdgeDriver((EdgeOptions)userDriverOptions),
                        _ => userDriverOptions == null
                            ? new ChromeDriver()
                            : new ChromeDriver((ChromeOptions)userDriverOptions)
                    };

                    ConsoleOut.WriteReport("Running on 'Local Machine'.");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
            }           
        }

        /// <summary>
        /// Navigates the browser to the specified URL and maximizes the window.
        /// </summary>
        /// <param name="url">The URL to navigate to.</param>
        public void Navigate(string url)
        {
            Driver.Manage().Window.Maximize();
            Driver.Navigate().GoToUrl(url);
            ConsoleOut.WriteReport($"Opened Browser to '{url}'.");
        }

        /// <summary>
        /// Closes and quits the browser session.
        /// </summary>
        public void Close()
        {
            try
            {
                Driver?.Close();
            }
            catch (NoSuchWindowException) { /* Ignore if already closed */ }
            try
            {
                Driver?.Quit();
            }
            catch (WebDriverException) { /* Ignore if already quit */ }
        }

        /// <summary>
        /// Retrieves the Selenium Grid node URI for the current session and sets the <see cref="Node"/> property.
        /// </summary>
        /// <returns>A task representing the asynchronous operation.</returns>
        private async Task GetVMNodeName()
        {
            try
            {
                if (Driver == null)
                    return;

                // Build the GraphQL query for the Selenium Grid API
                string seleniumGridApi = $"{Hub}/graphql";
                var sessionId = Driver.GetType().GetProperty("SessionId")?.GetValue(Driver)?.ToString();
                if (string.IsNullOrEmpty(sessionId))
                    return;

                string query = $"{{\"query\":\"{{ session (id: \\\"{sessionId}\\\") {{ id, uri, nodeId, nodeUri }} }} \"}}";

                using var client = new HttpClient();
                using var requestContent = new StringContent(query, System.Text.Encoding.UTF8, "application/json");
                using var webResponse = await client.PostAsync(seleniumGridApi, requestContent);
                string response = await webResponse.Content.ReadAsStringAsync();

                JObject res = JObject.Parse(response);
                Node = res["data"]?["session"]?["nodeUri"]?.ToString() ?? string.Empty;
            }
            catch (Exception e)
            {
                ConsoleOut.WriteReport($"Error Getting VM Name!\r\nException Message: {e.Message}");
            }
        }

        /// <summary>
        /// Adds network authentication credentials for the specified domain and starts network monitoring.
        /// </summary>
        /// <param name="userName">The username for authentication.</param>
        /// <param name="password">The password for authentication.</param>
        /// <param name="domain">The domain to match for authentication. Default is "healthtrustpg.com".</param>
        /// <returns>A task representing the asynchronous operation.</returns>
        public async Task EnterCreds(string userName, string password, string domain = "healthtrustpg.com")
        {
            // Set up network authentication handler for the specified domain
            var handler = new NetworkAuthenticationHandler
            {
                UriMatcher = d => d.AbsoluteUri.Contains(domain, StringComparison.OrdinalIgnoreCase),
                Credentials = new PasswordCredentials(userName, password)
            };

            INetwork networkInterceptor = Driver.Manage().Network;
            networkInterceptor.AddAuthenticationHandler(handler);
            await networkInterceptor.StartMonitoring();
        }

        /// <summary>
        /// Takes a screenshot of the current browser window and saves it to the specified path.
        /// </summary>
        /// <param name="path">The file path to save the screenshot.</param>
        /// <returns>The path where the screenshot was saved.</returns>
        /// <exception cref="NotSupportedException">Thrown if the driver does not support taking screenshots.</exception>
        public string TakeScreenshot(string path)
        {
            if (Driver is ITakesScreenshot screenshotDriver)
            {
                var screenshot = screenshotDriver.GetScreenshot();
                screenshot.SaveAsFile(path);
                ConsoleOut.WriteReport($"Saved Screenshots to '{path}'.");
                return path;
            }
            throw new NotSupportedException("Driver does not support taking screenshots.");
        }

        /// <summary>
        /// Takes a screenshot of the current browser window and returns it as a Base64-encoded string.
        /// </summary>
        /// <returns>The Base64-encoded screenshot string.</returns>
        /// <exception cref="NotSupportedException">Thrown if the driver does not support taking screenshots.</exception>
        public string TakeBase64Screenshot()
        {
            if (Driver is ITakesScreenshot screenshotDriver)
            {
                return screenshotDriver.GetScreenshot().AsBase64EncodedString;
            }
            throw new NotSupportedException("Driver does not support taking screenshots.");
        }
    }
}