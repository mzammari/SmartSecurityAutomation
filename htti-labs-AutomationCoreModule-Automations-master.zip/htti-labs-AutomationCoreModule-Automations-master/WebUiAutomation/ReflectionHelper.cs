﻿using System;
using System.Reflection;

namespace WebUiAutomation
{
    public static class ReflectionHelper
    {
        /// <summary>
        /// Returns the PropertyInfo for a property, searching base types if necessary.
        /// </summary>
        /// <param name="type">The type to search.</param>
        /// <param name="propertyName">The property name.</param>
        /// <returns>The PropertyInfo if found; otherwise, null.</returns>
        private static PropertyInfo? GetPropertyInfo(Type type, string propertyName)
        {
            while (type != null)
            {
                var propInfo = type.GetProperty(propertyName,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (propInfo != null)
                    return propInfo;
                type = type.BaseType;
            }
            return null;
        }

        /// <summary>
        /// Gets the value of a property by name from an object, searching base types if necessary.
        /// </summary>
        /// <param name="obj">The object instance.</param>
        /// <param name="propertyName">The property name.</param>
        /// <returns>The property value.</returns>
        /// <exception cref="ArgumentNullException">If obj or propertyName is null.</exception>
        /// <exception cref="ArgumentOutOfRangeException">If the property is not found.</exception>
        public static object? GetPropertyValue(this object obj, string propertyName)
        {
            if (obj == null)
                throw new ArgumentNullException(nameof(obj));
            if (propertyName == null)
                throw new ArgumentNullException(nameof(propertyName));

            var propInfo = GetPropertyInfo(obj.GetType(), propertyName);
            if (propInfo == null)
                throw new ArgumentOutOfRangeException(nameof(propertyName),
                    $"Couldn't find property '{propertyName}' in type '{obj.GetType().FullName}' or its base types.");
            return propInfo.GetValue(obj);
        }
    }
}