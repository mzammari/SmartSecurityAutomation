﻿using System;
using System.Linq;
using AutomationCoreLite.Reporting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;

namespace WebUiAutomation
{
    /// <summary>
    /// Represents a wrapper for an <see cref="IWebElement"/> with additional helper methods for UI automation.
    /// </summary>
    public class HpgElement
    {
        /// <summary>
        /// Gets the underlying Selenium <see cref="IWebElement"/>.
        /// </summary>
        public IWebElement Element { get; }

        /// <summary>
        /// Gets the associated Selenium <see cref="IWebDriver"/>, if available.
        /// </summary>
        public IWebDriver? Driver { get; }

        private string? _identifier;

        /// <summary>
        /// Gets a descriptive identifier for the element, such as name, id, text, or tag name.
        /// </summary>
        public string Identifier
        {
            get
            {
                if (_identifier == null)
                {
                    // Try to get the most descriptive identifier available
                    _identifier = Element.GetAttribute("name")
                        ?? Element.GetAttribute("id")
                        ?? (!string.IsNullOrWhiteSpace(Element.Text) ? string.Join("", Element.Text.Trim().Take(30)) : null)
                        ?? Element.TagName
                        ?? "HpgElement";
                }
                return _identifier;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="HpgElement"/> class with the specified element.
        /// </summary>
        /// <param name="element">The Selenium web element.</param>
        public HpgElement(IWebElement element) : this(element, null, null) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="HpgElement"/> class with the specified element and identifier.
        /// </summary>
        /// <param name="element">The Selenium web element.</param>
        /// <param name="identifier">A custom identifier for the element.</param>
        public HpgElement(IWebElement element, string? identifier) : this(element, identifier, null) { }

        /// <summary>
        /// Initializes a new instance of the <see cref="HpgElement"/> class with the specified element, identifier, and driver.
        /// </summary>
        /// <param name="element">The Selenium web element.</param>
        /// <param name="identifier">A custom identifier for the element.</param>
        /// <param name="driver">The Selenium web driver.</param>
        public HpgElement(IWebElement element, string? identifier, IWebDriver? driver)
        {
            Element = element ?? throw new ArgumentNullException(nameof(element));
            _identifier = identifier;
            Driver = driver;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="HpgElement"/> class using a <see cref="WebDriverWait"/> and a locator.
        /// </summary>
        /// <param name="webDriver">The WebDriverWait instance.</param>
        /// <param name="identifier">The locator for the element.</param>
        /// <param name="identity">A custom identifier for the element.</param>
        public HpgElement(WebDriverWait webDriver, By identifier, string identity)
        {
            _identifier = identity;
            Element = webDriver.Until(driver => driver.FindElement(identifier));
        }

        /// <summary>
        /// Gets the text content of the element.
        /// </summary>
        public string Text => Element.Text;

        /// <summary>
        /// Clicks the element, waiting until it is clickable.
        /// </summary>
        /// <param name="timeToWait">The time to wait in seconds before clicking. Default is 0.</param>
        /// <exception cref="InvalidOperationException">Thrown if the driver is not set.</exception>
        public void Click(int timeToWait = 0)
        {
            if (Driver == null)
                throw new InvalidOperationException("Driver is not set for this element.");
            var wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(timeToWait));
            wait.Until(driver => Element.Displayed && Element.Enabled);
            try
            {
                Element.Click();
                ConsoleOut.WriteReport($"Clicked on '{Identifier}'.");
            }
            catch (Exception e)
            {
                Console.WriteLine($"Unable to click on element: '{Identifier}'! Error Exception: {e}");
                throw;
            }
        }

        /// <summary>
        /// Scrolls the element into view using JavaScript.
        /// </summary>
        /// <exception cref="InvalidOperationException">Thrown if the driver is not set.</exception>
        public void ScrollIntoView()
        {
            if (Driver == null)
                throw new InvalidOperationException("Driver is not set for this element.");
            try
            {
                Driver.ExecuteJavaScript("arguments[0].scrollIntoView(true);", Element);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Unable to scroll to Element: '{Identifier}'!\r\nError: {e}");
                throw;
            }
        }

        /// <summary>
        /// Moves the mouse to the center of the element and then to the specified x and y offset from the center, then clicks.
        /// </summary>
        /// <param name="x">The horizontal offset from the center of the element.</param>
        /// <param name="y">The vertical offset from the center of the element.</param>
        /// <exception cref="InvalidOperationException">Thrown if the driver is not set.</exception>
        public void ClickOffSet(int x, int y)
        {
            if (Driver == null)
                throw new InvalidOperationException("Driver is not set for this element.");
            new Actions(Driver).MoveToElement(Element, x, y).Click().Perform();
        }

        /// <summary>
        /// Determines whether the element exists and is displayed.
        /// </summary>
        /// <param name="outputToConsole">Whether to output the result to the console.</param>
        /// <returns><c>true</c> if the element exists and is displayed; otherwise, <c>false</c>.</returns>
        public bool Exists(bool outputToConsole = false)
        {
            try
            {
                bool displayed = Element.Displayed;
                if (outputToConsole)
                    ConsoleOut.WriteReport($"Element '{Identifier}' exists is {displayed}.");
                return displayed;
            }
            catch(NoSuchElementException) 
            {
                if (outputToConsole)
                    ConsoleOut.WriteReport($"Element '{Identifier}' exists is false.");
                return false;
            }
        }

        /// <summary>
        /// Types the specified value into the element.
        /// </summary>
        /// <param name="value">The value to type.</param>
        public void Type(string value)
        {
            Element.SendKeys(value);
            ConsoleOut.WriteReport($"Typed '{value}' to Element '{Identifier}'");
        }
    }
}