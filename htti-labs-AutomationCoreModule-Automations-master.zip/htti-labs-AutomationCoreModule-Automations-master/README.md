![alt text](https://github.com/HCAHealthtrust/htti-labs-AutomationCoreModule-Automations/blob/master/HCA_logo.png "HCA Logo")
# QA Automation Modules
This solution houses multiple projects around test automation. Below you will find links to the different projects and a description of each. If you update any of the projects, please make sure you update the appropriate README.md file on what was changed/added and how to properly implement it.

## Modules

|Module | Description |
| ---- | ---- |
| [Automation Core Lite](AutomationCoreLite) | The main testing framework (xUnit), reporting classes, assertions, report generator, and Rally Updater  |
| [Web UI Automation](WebUiAutomation) | Selenium framework and utilizes the Automation Core lite for reporting |
| [ADO Plugin](AzureDevOpsTestPlugin) | Azure Dev Ops plugin to create test runs and create test case results  |