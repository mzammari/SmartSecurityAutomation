﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationCoreLite.Reporting.Template
{
    internal static class HtmlTemplate
    {
        public static string GetHtmlTemplate()
        {
            return @"<!DOCTYPE html>
<html lang=""en"">
<style>
    body {
        background: linear-gradient(to right, #00c6ff, #0072ff);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 20px;
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    th, td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
    }

    th {
        background-color: #4CAF50;
        color: white;
    }

    tr:nth-child(odd) {
        background-color: #fffdfd;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    tr:hover {
        background-color: #e0f7fa;
    }

    .screenshot-icon {
        width: 35px;
        height: 35px;
        cursor: pointer;
        transition: transform 0.2s;
        padding: 3px 3px 3px 3px;
    }

        .screenshot-icon:hover {
            transform: scale(1.2);
        }

    h1 {
        color: #0072ff;
        text-align: center;
    }

    .logo {
        width: 100px;
        height: auto;
        position: absolute;
        top: 20px;
        left: 20px;
    }
</style>
<head>
    <style>
        h1 {
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }
    </style>
    <meta charset=""UTF-8"">
    <style>
        .header-info {
            margin: 20px 0;
            padding: 10px;
            background-color: #e3f2fd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .header-info h2 {
            margin: 0;
            color: #0072ff;
        }
        .header-info p {
            margin: 5px 0;
            color: #333;
        }
        .header-info .status {
            font-weight: bold;
            color: #d32f2f;
        }
        .header-info .status.pass {
            color: #388e3c;
        }
        
    </style>
    <title>Selenium Test Case Results</title>
    
    <img name=""HCA Logo"" id=""logo"" src=""{company_logo}"" alt=""Logo"" class=""logo"" style=""position: relative;top: 0px;right: 0px;"" >  
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">    
    <div class=""header-info"">
        <h2 id=""testName"">Test Name: Sample Test</h2>
        <p id=""Environment"">Environment: Production</p>
        <p id=""DateRan"">Date Ran: 2023-10-01</p>
        <p id=""Status"" class=""status"">Status: fail</p>
    </div>    
</head>
<body>
    
    <table>
        <thead>
            <tr>
                <th>Test Step No.</th>
                <th>Test Step</th>
                <th>Actions</th>
                <th>Expected Result</th>                
                <th>Screenshot</th>
            </tr>
        </thead>
        <tbody>            
            <!-- Add more test steps as needed -->
        </tbody>
    </table>

    <script>
        function showScreenshot(imgElement) {
            const modal = document.createElement('div');
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
            modal.style.display = 'flex';
            modal.style.alignItems = 'center';
            modal.style.justifyContent = 'center';
            modal.style.zIndex = '1000';

            const img = document.createElement('img');
            img.src = imgElement.src;
            img.style.maxWidth = '90%';
            img.style.maxHeight = '90%';
            img.style.boxShadow = '0 0 10px #fff';

            modal.appendChild(img);

            modal.onclick = function() {
            document.body.removeChild(modal);
            };

            document.body.appendChild(modal);
        }        
        
    </script>
</body>
</html>";
        }
    }
}
