﻿using System;
using System.Reflection.Metadata;
using Xunit;

namespace AutomationCoreLite.Reporting;

public class HPGAssert
{
    /// <summary>
    /// Validates if condition is True as expected
    /// </summary>
    /// <param name="expected">Flag: expected condition</param>
    /// <param name="message">The message to display</param>
    public static void True(bool expected, string message = "Condition is not true.")
    {
        try
        {
            Assert.True(expected, message);
        }
        catch (Exception)
        {
            ConsoleOut.WriteReport(message);
            throw;
        }

        ConsoleOut.WriteReport("Test for " + message + " evaluating to true passed.");
    }

    /// <summary>
    /// Validates if condition is false as expected
    /// </summary>
    /// <param name="expected">Flag: expected condition</param>
    /// <param name="message">The message to display</param>
    public static void False(bool expected, string message = "Condition is not false.")
    {
        try
        {
            Assert.False(expected, message);
        }
        catch (Exception)
        {
            ConsoleOut.WriteReport(message);
            throw;
        }

        ConsoleOut.WriteReport("Test for " + message + " evaluating to false passed.");
    }

    /// <summary>
    /// Displays message and throws exception if condition fails
    /// </summary>
    public static void Fail()
    {
        ConsoleOut.WriteReport("Fail call was made.");
        Assert.Fail("Fail call was made.");
    }

    /// <summary>
    /// Displays a failed message passed into a throw exception
    /// </summary>
    /// <param name="failMessage">Fail message to display</param>
    public static void Fail(string failMessage)
    {
        ConsoleOut.WriteReport($"Fail call was made-{failMessage}");
        Assert.Fail(failMessage);
    }

    /// <summary>
    /// Validates if Actual value matches Expected value. If not, a warning is produced
    /// </summary>
    /// <param name="expected">Expected string value</param>
    /// <param name="actual">Actual string value</param>
    public static void AreEqual(string expected, string actual)
    {
        AreEqual(expected, actual, actual + " does not match the expected value of " + expected);
    }

    /// <summary>
    /// Validates if Actual value matches Expected value with a message
    /// </summary>
    /// <param name="expected">Expected string value</param>
    /// <param name="actual">Actual string value</param>
    /// <param name="message">The message to display</param>
    public static void AreEqual(string expected, string actual, string message)
    {
        try
        {
            Assert.Equal(expected, actual);
            
        }
        catch (Exception)
        {
            ConsoleOut.WriteReport(message);
            throw;
        }

        ConsoleOut.WriteReport("Both values are " + truncate(actual)); //Changed by WP 9/18/14 to truncate test output
    }

    /// <summary>
    /// Validates Actual value does not match the expected value with a message
    /// </summary>
    /// <param name="expected">Expected string value</param>
    /// <param name="actual">Actual string value</param>
    /// <param name="message">The message to display</param>
    public static void AreNotEqual(string expected, string actual, string message = "")
    {
        try
        {
            Assert.NotEqual(expected, actual);
        }
        catch (Exception)
        {
            ConsoleOut.WriteReport(message);
            throw;
        }

        ConsoleOut.WriteReport("Both values are not equal, which is as expected.");
        ConsoleOut.WriteReport("Expected '" + truncate(expected) + "'");
        ConsoleOut.WriteReport("Actual '" + truncate(actual) + "'");
    }

    /// <summary>
    /// This truncates the entire string to a length of 97 and 3 dots if it is greater than 100
    /// </summary>
    /// <param name="entireString">The entire string</param>
    /// <param name="length">The constraint value for the length of the entire string</param>
    /// <returns>Truncated string unless its length is less than the defined constraint which returns the entire string</returns>
    //Added by WP 9/18/2014
    private static string truncate(string entireString, int length = 100)
    {
        if (entireString.Length > length)
        {
            return entireString.Substring(0, length - 3) + "...";
        }

        return entireString;
    }

    /// <summary>
    /// Validates if one string contains another string. If not, a warning is produced
    /// </summary>
    /// <param name="entireValue">The entire string value</param>
    /// <param name="containedValue">The value to be contained in the entire string</param>
    public static void Contains(string entireValue, string containedValue)
    {
        Contains(entireValue, containedValue,
            "'" + containedValue + "' was not contained within '" + entireValue + "'");
    }

    /// <summary>
    /// Validates if one string contains another string with a message
    /// </summary>
    /// <param name="entireValue">The entire string value</param>
    /// <param name="containedValue">The value to be contained in the entire string</param>
    /// <param name="message">The message to display</param>
    public static void Contains(string entireValue, string containedValue, string message)
    {
        if (!entireValue.Contains(containedValue))
        {
            ConsoleOut.WriteReport(message);
            Assert.Fail(message);
        }

        ConsoleOut.WriteReport("'" + containedValue + "' was found within '" + entireValue + "' as expected.");
    }

}