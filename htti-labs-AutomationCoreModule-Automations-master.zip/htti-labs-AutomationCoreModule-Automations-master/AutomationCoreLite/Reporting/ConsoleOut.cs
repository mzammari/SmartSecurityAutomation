﻿using System;
using System.Text;

namespace AutomationCoreLite.Reporting;

public class ConsoleOut
{
    private const int ReportPadding = 1;

    /// <summary>
    /// Below are the functions to wrap the WriteLine Method so that the code is more readable
    /// and if the reporter changes we can easily change where to write
    /// </summary>
    /// <param name="message">Either a simple string or Format string (if passing variables as well)</param>
    /// <param name="writeConsoleEntry">Optional argument (default is true) to suppress writing to Console</param>
    public static void WriteReport(string message, bool writeConsoleEntry = true)
    {
        ReportOutput.AppendLine(message);
        if (Steps.CurrentTestCaseStep != null) 
            Steps.CurrentTestCaseStep.Actions.Add(message);
        
        if (!writeConsoleEntry) return;
        message = AddReportPadding(message);
        Console.WriteLine(message);
    }
    /// <summary>
    /// Adds the padding to the report string
    /// </summary>
    /// <param name="toBePadded">The string to have padded</param>
    /// <returns>The string after being padded</returns>
    private static string AddReportPadding(string toBePadded)
    {
        int i;
        StringBuilder paddedString = new StringBuilder();
        for (i = ReportPadding; i >= 0; i--)
        {
            paddedString.Append("    ");
        }
        paddedString.Append(toBePadded);
        return paddedString.ToString();
    }
}