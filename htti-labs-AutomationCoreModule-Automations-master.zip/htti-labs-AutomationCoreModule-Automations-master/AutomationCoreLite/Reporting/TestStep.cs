﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationCoreLite.Reporting
{
    public class TestStep
    {
        public TestStep(int stepNumber, string stepDescription, string expectedResult)
        {
            StepNumber = stepNumber;
            StepDescription = stepDescription;
            ExpectedResult = expectedResult;
            Actions = new List<string>();
            ScreenShots = new List<string>();
        }

        public int StepNumber { get; set; }
        public string StepDescription { get; set; }
        public string ExpectedResult { get; set; }
        public List<string> Actions { get; set; }
        public List<string> ScreenShots { get; set; }        
    }
    
}
