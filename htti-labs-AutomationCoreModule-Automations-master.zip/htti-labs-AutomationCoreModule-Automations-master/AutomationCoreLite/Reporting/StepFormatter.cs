﻿namespace AutomationCoreLite.Reporting
{
    public class StepFormatter
    {
        /// <summary>
        /// Replaces a step value with a new value if the step length is greater than specified constraint
        /// </summary>
        /// <param name="steps">The steps to be formatted</param>
        /// <returns>New value if step length is longer than constraint. Old value if length constraint is not broken
        /// </returns>
        public string Format(string steps)
        {
            // too long? strip the lines out
            if (steps.Length > 32768)
            {
                steps = steps.Replace("_", "");
            }

            // still too long? abbreviate "Expected:"
            if (steps.Length > 32768)
            {
                steps = steps.Replace("Expected :", "Exp:");
            }

            //return System.Web.HttpUtility.JavaScriptStringEncode(steps);

            return steps.Replace("\r\n", "<br>");
        }
    }
}