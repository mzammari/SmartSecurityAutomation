﻿using AutomationCoreLite.Reporting.Template;
using System;
using System.Collections.Generic;
using System.IO;
using HtmlAgilityPack;

namespace AutomationCoreLite.Reporting
{
    public class ReportGenerator
    {
        public ReportGenerator(string applicationName, string testName, string environment, DateTime dateRan, bool isPass)
        {
            ApplicationName = applicationName;
            TestName = testName;
            Environment = environment;
            DateRan = dateRan;
            IsPass = isPass;
        }

        public string ApplicationName { get; set; }
        public string TestName { get; set; }
        public string Environment { get; set; }
        public DateTime DateRan { get; set; }
        public bool IsPass { get; set; }
        public string? Logo { get; set; }

        private HtmlDocument _htmlDocument;

        /// <summary>
        /// Generates the HTML report.
        /// </summary>
        /// <param name="testSteps"></param>
        /// <param name="fileName"></param>
        public string GenerateReport(List<TestStep> testSteps, string fileName)
        {
            GetHtmlTemplate();
            PopulateTitleAndHeader();
            PopulateTestSteps(testSteps);

            var fullFileName = $"{fileName}.html";
            _htmlDocument.Save(fullFileName);

            return fullFileName;
        }

        /// <summary>
        /// Gets the template html file.
        /// </summary>
        /// <returns></returns>
        private void GetHtmlTemplate()
        {
            _htmlDocument = new HtmlDocument();
            _htmlDocument.LoadHtml(HtmlTemplate.GetHtmlTemplate());
        }

        /// <summary>
        /// Populates the Title, Company Logo, and Header of the report.
        /// </summary>
        private void PopulateTitleAndHeader()
        {
            //title
            var title = _htmlDocument.DocumentNode.SelectSingleNode("//title");
            title.InnerHtml = ApplicationName;

            //logo            
            var logo = _htmlDocument.DocumentNode.SelectSingleNode("//img[@id='logo']");
            logo.SetAttributeValue("src", ( Logo != null && Logo.ToString() != "" ) ? Logo : Logos.HcaLogo);

            //Header
            var testName = _htmlDocument.DocumentNode.SelectSingleNode("//h2[@id='testName']");
            testName.InnerHtml = $"Test Name: {TestName}";
            var environment = _htmlDocument.DocumentNode.SelectSingleNode("//p[@id='Environment']");
            environment.InnerHtml = $"Environment: {Environment}";
            var dateRan = _htmlDocument.DocumentNode.SelectSingleNode("//p[@id='DateRan']");
            dateRan.InnerHtml = $"Date Ran: {DateRan:F}";
            var status = _htmlDocument.DocumentNode.SelectSingleNode("//p[@id='Status']");
            if (IsPass)
            {
                status.InnerHtml = "Status: Pass";
                status.SetAttributeValue("class", "status pass");
            }
            else
            {
                status.InnerHtml = "Status: Fail";
                status.SetAttributeValue("class", "status");
            }
        }

        /// <summary>
        /// Populates the test steps of the report.
        /// </summary>
        /// <param name="testSteps"></param>
        private void PopulateTestSteps(List<TestStep> testSteps)
        {
            var table = _htmlDocument.DocumentNode.SelectSingleNode("//tbody");
            foreach (var testStep in testSteps)
            {
                var row = _htmlDocument.CreateElement("tr");

                var stepNumber = _htmlDocument.CreateElement("td");
                stepNumber.SetAttributeValue("style", "text-align: center;");
                stepNumber.InnerHtml = testStep.StepNumber.ToString();
                row.AppendChild(stepNumber);

                var stepDescription = _htmlDocument.CreateElement("td");
                stepDescription.InnerHtml = testStep.StepDescription;
                row.AppendChild(stepDescription);

                var action = _htmlDocument.CreateElement("td");
                action.AppendChild(PopulateAction(testStep.Actions));
                row.AppendChild(action);

                var expected = _htmlDocument.CreateElement("td");
                expected.InnerHtml = testStep.ExpectedResult;
                row.AppendChild(expected);

                var screenShots = _htmlDocument.CreateElement("td");
                screenShots.AppendChild(PopulateScreenShots(testStep.ScreenShots));
                row.AppendChild(screenShots);

                table.AppendChild(row);
            }
        }

        /// <summary>
        /// Populates the actions of the test step.
        /// </summary>
        /// <param name="actions"></param>
        /// <returns></returns>
        private HtmlNode PopulateAction(List<string> actions)
        {
            var actionNodes = _htmlDocument.CreateElement("ol");

            foreach (var action in actions)
            {
                var actionNode = _htmlDocument.CreateElement("li");
                actionNode.InnerHtml = action;
                actionNodes.AppendChild(actionNode);
            }

            return actionNodes;
        }

        /// <summary>
        /// Populates the screenshots of the test step.
        /// </summary>
        /// <param name="screenShots"></param>
        /// <returns></returns>
        private HtmlNode PopulateScreenShots(List<string> screenShots)
        {
            var screenShotNodes = _htmlDocument.CreateElement("div");
            foreach (var screenShot in screenShots)
            {
                var screenShotNode = _htmlDocument.CreateElement("img");
                screenShotNode.SetAttributeValue("src", $"data:image/png;base64,{screenShot}");
                screenShotNode.SetAttributeValue("alt", "screenshot");
                screenShotNode.SetAttributeValue("class", "screenshot-icon");
                screenShotNode.SetAttributeValue("onclick", "showScreenshot(this)");
                screenShotNodes.AppendChild(screenShotNode);
            }
            return screenShotNodes;
        }
    }
}
