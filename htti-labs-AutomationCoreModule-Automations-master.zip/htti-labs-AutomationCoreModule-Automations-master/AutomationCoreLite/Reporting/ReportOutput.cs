﻿using System;
using System.Text;

namespace AutomationCoreLite.Reporting
{
    public static class ReportOutput
    {
        private static readonly StringBuilder reportOut = new();

        private static string lastOutput = "";
        private static readonly StringBuilder chunk = new();

        /// <summary>
        /// Gets entire report output or sets report output to specified string
        /// </summary>
        public static string ReportOut
        {
            get => reportOut.ToString();
            set
            {
                reportOut.Clear();
                reportOut.Append(value);
                chunk.Append(value);
                lastOutput = value;
            }
        }

        /// <summary>
        /// Returns the last output
        /// </summary>
        public static string Last => lastOutput;

        /// <summary>
        /// Returns everything added since the last call to Chunk
        /// </summary>
        public static string Chunk
        {
            get
            {
                var rtrnChunk = chunk.ToString();
                chunk.Clear();
                return rtrnChunk;
            }
        }

        /// <summary>
        /// Append a new line of text to the output
        /// </summary>
        /// <param name="line">Text to be added to a new line of output</param>
        /// <param name="outputProgress">Output line to current output window immediately</param>
        /// <returns>Returns complete appended report</returns>
        public static string AppendLine(string line, bool outputProgress = false)
        {
            reportOut.AppendLine(line);
            chunk.AppendLine(line);
            lastOutput = line;
            //if (outputProgress) TestContext.Progress.WriteLine(line);
            return ReportOut;
        }

        /// <summary>
        /// Append new text to the output
        /// </summary>
        /// <param name="text">Text to be added to the end of the output</param>
        /// <param name="outputProgress">Output text to current output window immediately</param>
        /// <returns>Returns complete appended report</returns>
        public static string AppendText(string text, bool outputProgress = false)
        {
            reportOut.Append(text);
            chunk.Append(text);
            lastOutput = text;
            //if (outputProgress) TestContext.Progress.Write(text);
            return ReportOut;
        }

        /// <summary>
        /// Clears entire contents of report output
        /// </summary>
        public static void Clear()
        {
            reportOut.Clear();
            chunk.Clear();
        }

        public static string SaveToFile(string outFile)
        {
            System.IO.File.WriteAllText(outFile, reportOut.ToString());
            return outFile;
        }

        /// <summary>
        /// Gets UTF32-encoded byte-array of entire report output
        /// </summary>
        /// <returns>UTF32-encoded byte-array of entire report output</returns>
        public static byte[] ToBytes()
        {
            return System.Text.Encoding.UTF32.GetBytes(reportOut.ToString());
        }

        /// <summary>
        /// Gets Base64-encoded string of entire report output
        /// </summary>
        /// <returns>Base64-encoded string of entire report output</returns>
        public static string ToBase64()
        {
            return Convert.ToBase64String(ToBytes());
        }

        /// <summary>
        /// Gets HTML-encoded string of entire report output
        /// </summary>
        /// <returns>HTML-encoded string of entire report output</returns>
        public static string ToHTML()
        {
            return System.Web.HttpUtility.HtmlEncode(reportOut.ToString());
        }
    }
}