﻿using System;
using System.Collections.Generic;

namespace AutomationCoreLite.Reporting
{
    public class HPGWarn
    {
        static HPGWarn()
        {
            warningsHolder.Warnings = new List<HpgWarning>();
        }

        /// <summary>
        /// Validate actual value is True as expected.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="actual">Value to test if it is True</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool True(bool actual, bool failing = true, string field = null)
        {
            return True(actual, "Validate condition is True.", failing, field);
        }

        /// <summary>
        /// Validate actual value is True as expected.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="actual">Value to test if it is True</param>
        /// <param name="message">Message to log if test passes/fails</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool True(bool actual, string message, bool failing = true, string field = null)
        {
            if (!actual)
            {
                Warn(message + " FAILED!" + (field != null ? $" For Field: '{field}'." : string.Empty), failing);
                return actual;
            }

            ConsoleOut.WriteReport("Test for " + message + " evaluating to true passed." +
                                    (field != null ? $" For Field: '{field}'." : string.Empty));
            return actual;
        }

        /// <summary>
        /// Validate actual value is False as expected.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="actual">Value to test if it is False</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool False(bool actual, bool failing = true, string field = null)
        {
            return False(actual, "Validate condition is False.", failing, field);
        }

        /// <summary>
        /// Validate actual value is False as expected.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="actual">Value to test if it is False</param>
        /// <param name="message">Message to log if test passes/fails</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool False(bool actual, String message, bool failing = true, string field = null)
        {
            if (actual)
            {
                Warn(message + " FAILED!" + (field != null ? $" For Field: '{field}'." : string.Empty), failing);
                return !actual;
            }

            ConsoleOut.WriteReport("Test for " + message + " evaluating to false passed." +
                                    (field != null ? $"For Field: '{field}'." : string.Empty));
            return !actual;
        }

        /// <summary>
        /// Validate Actual value matches Expected value.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="expected">Expected string value</param>
        /// <param name="actual">Actual string value</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool AreEqual(string expected, string actual, bool failing = true, bool toTruncate = true,
            string field = null)
        {
            return AreEqual(expected, actual, $"'{truncate(actual, toTruncate: toTruncate)}' does not match the expected value of '{truncate(expected)}'",
                failing, toTruncate, field);
        }

        /// <summary>
        /// Validate Actual value matches Expected value.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="expected">Expected string value</param>
        /// <param name="actual">Actual string value</param>
        /// <param name="message">Message to log if test passes/fails</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool AreEqual(string expected, string actual, string message, bool failing = true,
            bool toTruncate = true, string field = null)
        {
            //NUnit.Framework.Warn.If(() => actual, Is.Not.EqualTo(expected).IgnoreCase.NoClip, message);  Wish I could capture the DIFF like before
            if (actual.ToLower() != expected.ToLower())
            {
                Warn(
                    message + ". VALUES WERE NOT EQUAL!" +
                    (field != null ? $" For Field: '{field}'." : string.Empty),
                    failing);
                ConsoleOut.WriteReport("Expected: '" + truncate(expected, toTruncate: toTruncate) + "'");
                ConsoleOut.WriteReport("Actual: '" + truncate(actual, toTruncate: toTruncate) + "'");
                return false;
            }

            ConsoleOut.WriteReport("Both values are '" + truncate(actual, toTruncate: toTruncate) +
                                    (field != null ? $"' For Field: '{field}'." : "'"));
            return actual == expected;
        }

        /// <summary>
        /// Validate Actual value DOES NOT match Expected value.  If so, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="expected">String value to match</param>
        /// <param name="actual">Actual string value</param>
        /// <param name="message">Message to log if test passes/fails</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool AreNotEqual(string expected, string actual, string message = "Validate values are not equal",
            bool failing = true, bool toTruncate = true, string field = null)
        {
            //NUnit.Framework.Warn.If(() => actual, Is.EqualTo(expected).IgnoreCase, message); Wish I could capture the DIFF like before
            if (actual.ToLower() == expected.ToLower())
            {
                Warn(message + " BUT VALUES WERE EQUAL!", failing);
                ConsoleOut.WriteReport("Both values are equal, which is NOT as expected." +
                                        (field != null ? $" For Field: '{field}'." : string.Empty));
                ConsoleOut.WriteReport("Values: '" + truncate(expected, toTruncate: toTruncate) + "'");
                return false;
            }

            ConsoleOut.WriteReport("Both values are not equal, which is as expected." +
                                    (field != null ? $" For Field: '{field}'." : string.Empty));
            ConsoleOut.WriteReport("Expected '" + truncate(expected, toTruncate: toTruncate) + "'");
            ConsoleOut.WriteReport("Actual '" + truncate(actual, toTruncate: toTruncate) + "'");
            return actual != expected;
        }


        /// <summary>
        /// This truncates the entire string to a length of 97 and 3 dots if it is greater than 100
        /// </summary>
        /// <param name="entireString">The entire string</param>
        /// <param name="length">The constraint value for the length of the entire string</param>
        /// <returns>Truncated string length of 100 unless its length is less than the defined constraint which returns the entire string</returns>
        private static string truncate(string entireString, int length = 100, bool toTruncate = true)
        {
            if (entireString.Length > length && toTruncate)
            {
                return entireString.Substring(0, length - 3) + "...";
            }

            return entireString;
        }

        /// <summary>
        /// Test if a value is contained in another value.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="entireValue">Value to search in</param>
        /// <param name="containedValue">Value to search for</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool Contains(string entireValue, string containedValue, bool failing = true,
            bool toTruncate = true,
            string field = null)
        {
            return Contains(entireValue, containedValue,
                "'" + containedValue + "' was not contained within '" + truncate(entireValue, toTruncate: toTruncate) +
                "'",
                failing, toTruncate, field);
        }

        /// <summary>
        /// Test if a value is contained in another value.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="entireValue">Value to search in</param>
        /// <param name="containedValue">Value to search for</param>
        /// <param name="message">Message to log if test passes/fails</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool Contains(string entireValue, string containedValue, string message, bool failing = true,
            bool toTruncate = true, string field = null)
        {
            if (!entireValue.Contains(containedValue))
            {
                Warn(message + " - '" + containedValue + "' was NOT contained within '" +
                     truncate(entireValue, toTruncate: toTruncate) + "' as expected." +
                     (field != null ? $" For Field: '{field}'." : string.Empty));
                return false;
            }

            ConsoleOut.WriteReport("'" + containedValue + "' was found within '" +
                                    truncate(entireValue, toTruncate: toTruncate) + "' as expected." +
                                    (field != null ? $" For Field: '{field}'." : string.Empty));
            return true;
        }

        /// <summary>
        /// Test if the difference between two decimal values is within defined tolerance.  If not, a warning is produced and will fail if failing parameter is true
        /// </summary>
        /// <param name="val1">First decimal Value</param>
        /// <param name="val2">Second decimal Value</param>
        /// <param name="tolerance">Tolerance for difference between the two values</param>
        /// <param name="message">Message to log if test passes/fails</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static bool ValuesEqual(decimal val1, decimal val2, decimal tolerance, string message,
            bool failing = true)
        {
            try
            {
                //Assert.AreEqual((double)val1, (double)val2, (double)tolerance, message);  Would something like this be more better?
                var dif = Math.Abs(val1 - val2);
                if (dif > tolerance)
                {
                    Warn(
                        string.Format("'{0}' - {1} OUTSIDE TOLERANCE {2} !", message, dif, tolerance),
                        failing);
                }
            }
            catch (OverflowException e)
            {
                Warn(message + "-Exception: " + e.Message + e.StackTrace);
                return false;
            }

            ConsoleOut.WriteReport(message + " - values matched");
            return true;
        }

        /// <summary>
        /// Method to add an optional failing warning for generic use
        /// </summary>
        /// <param name="message">Warning message to add to warnings list</param>
        /// <param name="failing">Optional parameter.  Fail test at TearDown if a failing warning is present.  Default is True</param>
        public static void Warn(string message, bool failing = true)
        {
            var newWarning = new HpgWarning(message, failing);
            warningsHolder.Warnings.Add(newWarning);
            ConsoleOut.WriteReport("WARNING STEP " + newWarning.StepNumber + ": " + message);
        }

        /// <summary>
        /// Method to add a list of optional failing warning for generic use
        /// </summary>
        /// <param name="messages"></param>
        /// <param name="failing"></param>
        public static void WarnRange(List<string> messages, bool failing = true)
        {
            foreach (var message in messages)
            {
                var newWarning = new HpgWarning(message, failing);
                warningsHolder.Warnings.Add(newWarning);
                ConsoleOut.WriteReport("WARNING STEP " + newWarning.StepNumber + ": " + message);
            }
        }

        /// <summary>
        /// Readonly.  The current list of Warnings in the test so far.
        /// </summary>
        public static List<HpgWarning> Warnings => warningsHolder.Warnings;
    }

    public class HpgWarning
    {
        public          string Message;
        public          bool   Failing;
        public readonly int    StepNumber;

        public HpgWarning()
        {
            StepNumber = Steps.CurrentTestStep;
        }

        public HpgWarning(string message, bool failing = true)
        {
            StepNumber = Steps.CurrentTestStep;
            Message    = message;
            Failing    = failing;
        }
    }

    internal class warningsHolder
    {
        internal static List<HpgWarning> Warnings = new();
    }
}