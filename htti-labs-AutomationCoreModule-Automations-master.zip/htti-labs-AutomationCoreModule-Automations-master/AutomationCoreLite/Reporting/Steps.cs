﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace AutomationCoreLite.Reporting
{
    public static class Steps
    {
        private static int _counter;
        private static TimeSpan _stepTotalTime;
        private static readonly Stopwatch TestTime = new Stopwatch();
        private static readonly Stopwatch StepTime = new Stopwatch();
        private static readonly StringBuilder sbOutput = new StringBuilder();

        public static List<TestStep> TestSteps = new List<TestStep>();
        public static TestStep CurrentTestCaseStep;

        public static TimeSpan TestTotalTime   { get; private set; }
        public static string   StepsOutput     => sbOutput.ToString();
        public static int      CurrentTestStep => _counter;

        /// <summary>
        /// Begin Test Steps with no parameters.  Gets the test name via the stack.
        /// </summary>
        public static void BeginTestSteps()
        {
            // get call stack...
            StackTrace stackTrace = new StackTrace();

            // get calling method name...
            var testName = stackTrace.GetFrame(1).GetMethod().Name;
            BeginTestSteps(testName);
        }

        /// <summary>
        /// Begin Test steps with a specified test name
        /// </summary>
        /// <param name="testName">Name of the test</param>
        public static void BeginTestSteps(string testName)
        {
            _counter = 0;
            sbOutput.Clear();
            ReportOutput.Clear();

            string beginTestMessage = "Begin test : " + testName;

            WriteToOutputContainers(beginTestMessage, true);
            ReportOutput.AppendLine(beginTestMessage);

            TestTime.Start();
            StepTime.Start();
        }

        /// <summary>
        /// Be careful using this and the other overload in your test.  Your test step output could be incorrect.
        /// Adds a new step to the TestStep 
        /// </summary>
        /// <param name="stepNumber">Number of the step to be added</param>
        /// <param name="stepDescription">Description of the step to be added</param>
        /// <param name="stepExpectedResult">Expected Result of the step to be added</param>
        public static void AddTestStep(int stepNumber, string stepDescription, string stepExpectedResult)
        {
            _counter = stepNumber;

            // append time from last step to string
            _stepTotalTime = StepTime.Elapsed;
            TestTotalTime = TestTime.Elapsed;

            var elapsedTimeString = "Step Time Elapsed : "
                + _stepTotalTime + Environment.NewLine
                + "Test Time Elapsed : " + TestTotalTime;

            if(_counter > 1)
                TestSteps.Add(CurrentTestCaseStep);

            CurrentTestCaseStep = new TestStep(stepNumber, stepDescription, stepExpectedResult);

            WriteToOutputContainers(elapsedTimeString);

            StepTime.Restart();

            StringBuilder stepExpectedString = new StringBuilder();
            stepExpectedString.AppendLine("___________________________________________");
            stepExpectedString.AppendLine("Step " + stepNumber + ". " + stepDescription);
            stepExpectedString.AppendLine("Expected : " + stepExpectedResult);
            
            WriteToOutputContainers(stepExpectedString.ToString(), true);
            ReportOutput.AppendLine(stepExpectedString.ToString());
        }

        /// <summary>
        /// Adds a new step to the TestStep, the step number is auto incremented  
        /// </summary>
        /// <param name="stepDescription">Description of the step to be added</param>
        /// <param name="stepExpectedResult">Expected Result of the step to be added</param>
        public static void AddTestStep(string stepDescription, string stepExpectedResult)
        {
            _counter++;
            AddTestStep(_counter, stepDescription, stepExpectedResult);
        }

        /// <summary>
        /// Terminates the TestStep session
        /// </summary>
        public static void EndTestSteps()
        {
            TestTotalTime = TestTime.Elapsed;
            _stepTotalTime = StepTime.Elapsed;

            TestSteps.Add(CurrentTestCaseStep);

            StringBuilder endTestStepOutput = new StringBuilder();
            endTestStepOutput.AppendLine("Step Time Elapsed : " + _stepTotalTime);
            endTestStepOutput.AppendLine("Test Time Elapsed : " + TestTotalTime);
            endTestStepOutput.AppendLine("___________________________________________");

            WriteToOutputContainers(endTestStepOutput.ToString());
            ReportOutput.AppendLine(endTestStepOutput.ToString());
            
            TestTime.Restart();
            StepTime.Restart();
            TestTime.Stop();
            StepTime.Stop();
            
        }

        //Todo: includeConcise??
        /// <summary>
        /// Writes specified text to an output container
        /// </summary>
        /// <param name="textToWrite">Text that will be written to the output container</param>
        /// <param name="includeConcise">Flag:</param>
        private static void WriteToOutputContainers(string textToWrite, bool includeConcise = false)
        {
            Console.WriteLine(textToWrite);
            if (includeConcise) sbOutput.AppendLine(textToWrite);
        }

        /// <summary>
        /// Adds Screenshot to the current TestStep
        /// </summary>
        /// <param name="base64Image"></param>
        public static void AddScreenShot(string base64Image)
        {
            CurrentTestCaseStep.ScreenShots.Add(base64Image);
        }


    }
}

