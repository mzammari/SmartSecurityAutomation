# Automation Core Lite
The Automation Core Lite is a Library for the "Step" class, testing framework (xUnit), report formatting, report generator, and Rally updater.

Below you will find implementation examples for this library.

## Steps Class
The Step class is utilized to layout the test steps. It will basically be resemeble the manual test steps of your test case.
### Sample

```C#
Steps.BeginTestSteps("Test Name");

Steps.AddTestStep("Step 1 description.","Expected results.");

Steps.AddTestStep("Step 2 description.","Expected results");

Steps.EndTestSteps();
```

We can now add screenshots to the Steps class. It takes in a base 64 encoded image as an argument. (Version 1.2.0) There are two different ways to implement it.

Conversion Method:
```C#
Steps.AddScreenShot(( Browser.Driver as ITakesScreenshot ).GetScreenshot().AsBase64EncodedString);
```

Updated Automation Core Web Ui NuGet (1.1.3):
```C#
Steps.AddScreenShot(_browser.TakeBase64Screenshot());
```

## Rally Updater
The Rally Updater will create test cases results, upload attachments, and update the test steps field in the Rally project management tool.
### Sample

```C#
//Uploads test results to Rally
var rally = new Rally();
Dictionary<string, object> attachToObject = rally.JSONtoDictionary(
    rally.UploadTestCaseResult(RallyTestCaseId,
        rallyTestResult,
        GlobalTestVariables.AppName,
        Steps.TestTotalTime.TotalMinutes.ToString(),
        ReportOutput.ReportOut,
        machineName));

//Uploads attachments and attaches to the specified Rally Test Case Id.
foreach (var screenShot in GlobalTestVariables.RallyScreenShots)
{
    rally.UploadAndAttach(screenShot, true, screenShot.Split(Path.DirectorySeparatorChar).Last(),
        attachToObject);
}

//update Rally Test Case Steps
rally.UpdateTestSteps(RallyTestCaseId, Steps.StepsOutput);

```

## HTML Report Generator (Version: 1.2.0)
The HTML Report generator will take your "Steps", screenshots, and "ConsoleOut" information and create an HTML output report that is easier to read.

![alt text](https://github.com/HCAHealthtrust/htti-labs-AutomationCoreModule-Automations/blob/master/AutomationCoreLite/SampleTestCaseReport.png "Sample Report")

### Sample
```C#
//Generate Test HTML Report
var rg= new ReportGenerator(GlobalTestVariables.AppName
    , GlobalTestVariables.TestName
    ,GlobalTestVariables.TestEnvironment
    ,DateTime.Now
    ,Rally.Verdict.Pass == rallyTestResult);

var htmlFilePath = rg.GenerateReport(Steps.TestSteps, $"{GlobalTestVariables.ScreenShotFileLocation}\\{GlobalTestVariables.TestName}");
```
