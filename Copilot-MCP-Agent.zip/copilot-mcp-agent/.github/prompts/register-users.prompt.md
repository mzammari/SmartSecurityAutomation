---
name: register-users
description: Read users from the database, register each one on the Let's Shop site with Playwright, and save the credentials to Excel
agent: agent
argument-hint: How many users to register (default 3)
---
Goal: data-driven UI registration. Database → browser → Excel.

**Step 1: Get the test data (database server).**
Join `RegistrationDetails` to `UserNames` and return the first ${input:count:How many users? (e.g. 3)} users with: id_number, first_name, last_name, email, phone_number, occupation, gender, password, is_18_or_older. Show the SQL and the result table.

**Step 2: Make the data safe to re-run.**
The site rejects emails that are already registered. For each user, build a unique email of the form `<firstname><lastname><yyyyMMddHHmmss>@example.com`. If the database password doesn't meet the site's password rules (the page shows them when validation fails), generate one in the form `<Firstname><Lastname>@123` and use that. Keep a table of the values actually used.

**Step 3: Register each user (playwright server).**
For each user:
1. Open `https://rahulshettyacademy.com/client` and go to the **Register** page.
2. Take a snapshot and fill every field from the data: first name, last name, email, phone (digits only, 10 digits), occupation (if the database value isn't in the dropdown, pick the closest option and note it), gender, password and confirm password.
3. Tick the "18 years or older" checkbox **only if** `is_18_or_older` is true. If it's false, still click Register and record what the site does. This is our negative test.
4. Click **Register** and capture the success or error message.

**Step 4: Save the credentials (excel server).**
Write the users that registered successfully to `data/newdata.xlsx`, sheet `Sheet1`, starting at A1, with headers `Email | password | id_number | registered_at`. Overwrite the old rows. Use the absolute path to the file.

**Step 5: Report.**
Give a table: id_number | email used | expected result | actual message | PASS/FAIL. Expected result: success for adults, blocked for under-18.
