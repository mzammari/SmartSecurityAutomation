---
name: api-order
description: Log in via REST API with credentials from Excel, create an order, then verify it in the UI with Playwright
agent: agent
---
Goal: API + UI end-to-end. This replaces the course's Postman collection (EcomBasic).

**Step 1: Read the credentials (excel server).**
Read `data/newdata.xlsx`, `Sheet1` (use the absolute path). Take the first row's Email and password.

**Step 2: Log in (rest-api server).**
`POST /api/ecom/auth/login` with body `{ "userEmail": <email>, "userPassword": <password> }`.
Assert `message` equals `"Login Successfully"`. Keep `token` and `userId`.

**Step 3: Create an order (rest-api server).**
`POST /api/ecom/order/create-order` with header `Authorization: <token>` (the raw token, no "Bearer") and body:
`{ "orders": [ { "country": "India", "productOrderedId": "67a8dde5c0d3e6622a297cc8" } ] }`.
Assert `message` equals `"Order Placed Successfully"` and keep `orders[0]` as the order ID.
If the product ID is rejected, find a current product ID from the product-listing API or the site's dashboard, and retry once.

**Step 4: Verify in the UI (playwright server).**
Log in at `https://rahulshettyacademy.com/client` with the same credentials, open **Orders**, and confirm the order ID from step 3 is listed. Take a screenshot.

**Step 5: Report.**
A table with: step | request/action | expected | actual | PASS/FAIL. Mask the token (show only the first 8 characters).
