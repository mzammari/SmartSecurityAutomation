---
name: db-explore
description: Explore the RSAcademy database and answer questions with join queries
agent: agent
argument-hint: Optional question about the data, e.g. "which companies have repeat orders?"
---
Using the `database` MCP server:

1. List the tables in the database with their columns, primary keys and foreign keys, and draw a small ASCII diagram of the relationships.
2. Write and run these queries, showing the SQL and the results for each:
   - customers who have placed at least one order
   - companies with more than one order
   - every registered user joined to their email address (RegistrationDetails + UserNames)
   - for each city: number of customers, number of orders, and the most recent order date
3. If I added a question after the command, answer it too: ${input:question:Any extra question? (leave blank to skip)}
