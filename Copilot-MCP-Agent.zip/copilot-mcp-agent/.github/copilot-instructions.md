# Copilot instructions for this workspace

This workspace is an MCP "AI agent" test-automation demo. Work in **Agent mode** and use these MCP servers:

| Server | Use it for |
|---|---|
| `database` (DBHub) | Reading test data from the `RSAcademy` database. **Read-only**: never try INSERT, UPDATE, DELETE or DDL. Queries must start with SELECT or WITH (no DECLARE). |
| `playwright` | Driving the browser. Take a snapshot to find fields by their labels rather than guessing selectors. |
| `excel` | Reading and writing `data/newdata.xlsx`. The tools need an **absolute path**: use `${workspaceFolder}/data/newdata.xlsx` resolved to the full path. |
| `rest-api` | Calling `https://rahulshettyacademy.com` APIs. The base URL is already set, so pass only the path (e.g. `/api/ecom/auth/login`). |

Conventions:
- Before writing SQL, check table and column names with `search_objects`.
- Test users are fake demo data. Never use real personal data.
- The web app is `https://rahulshettyacademy.com/client` (the "Let's Shop" practice site).
- After each workflow, report results as a PASS/FAIL table, and show any SQL you ran.
- If a step fails (validation error, duplicate user, API error), capture the message, continue with the next record, and include the failure in the report. Don't retry forever.
