/* =====================================================================
   SQL Server port of the course's MySQL script (Untitled.sql)
   Creates database RSAcademy with the same 4 tables and sample rows.
   Run in SSMS as a sysadmin on your local / dev SQL Server.

   MySQL -> T-SQL changes: BOOLEAN -> BIT, TRUE/FALSE -> 1/0,
   AUTO_INCREMENT -> IDENTITY(1,1), USE/GO batches.
   ===================================================================== */
IF DB_ID(N'RSAcademy') IS NULL CREATE DATABASE RSAcademy;
GO
USE RSAcademy;
GO

CREATE TABLE dbo.RegistrationDetails (
    id_number      VARCHAR(50)  PRIMARY KEY,
    first_name     VARCHAR(100),
    last_name      VARCHAR(100),
    phone_number   VARCHAR(20),
    occupation     VARCHAR(100),
    gender         VARCHAR(10),
    password       VARCHAR(255),   -- plain text only because this is throwaway demo data
    is_18_or_older BIT
);

CREATE TABLE dbo.UserNames (
    id_number VARCHAR(50) PRIMARY KEY,
    email     VARCHAR(200),
    CONSTRAINT FK_UserNames_Registration FOREIGN KEY (id_number)
        REFERENCES dbo.RegistrationDetails(id_number)
);

INSERT INTO dbo.RegistrationDetails (id_number, first_name, last_name, phone_number, occupation, gender, password, is_18_or_older) VALUES
('USER001', 'John',  'Doe',    '123-456-7890', 'Engineer', 'Male',   '12345', 1),
('USER002', 'Jane',  'Smith',  '987-654-3210', 'Teacher',  'Female', '12345', 1),
('USER003', 'Peter', 'Jones',  '555-123-4567', 'Student',  'Male',   '12345', 0),
('USER004', 'Alice', 'Brown',  '111-222-3333', 'Doctor',   'Female', '12345', 1),
('USER005', 'David', 'Wilson', '444-555-6666', 'Artist',   'Male',   '12345', 1);

INSERT INTO dbo.UserNames (id_number, email) VALUES
('USER001', 'JohnDoe434@gmail.com'),
('USER002', 'JaneSmithgdfgf@gmail.com'),
('USER003', 'PeterJones5454@gmail.com'),
('USER004', 'AliceB3232wn@gmail.com'),
('USER005', 'DavidW24lson@gmail.com');

CREATE TABLE dbo.Customers (
    id   INT PRIMARY KEY,
    name VARCHAR(100),
    city VARCHAR(100),
    age  INT
);

CREATE TABLE dbo.Orders (
    order_id    INT IDENTITY(1,1) PRIMARY KEY,
    customer_id INT,
    subject     VARCHAR(100),
    company     VARCHAR(100),
    order_date  DATE,
    CONSTRAINT FK_Orders_Customers FOREIGN KEY (customer_id) REFERENCES dbo.Customers(id)
);

INSERT INTO dbo.Customers (id, name, city, age) VALUES
(1, 'Alice Smith',   'New York',    30),
(2, 'Bob Johnson',   'Los Angeles', 25),
(3, 'Charlie Brown', 'Chicago',     35),
(4, 'David Lee',     'New York',    28),
(5, 'Eve Williams',  'Houston',     32),
(6, 'Frank Miller',  'Los Angeles', 40);

INSERT INTO dbo.Orders (customer_id, subject, company, order_date) VALUES
(1, 'Laptop',              'Tech Solutions Inc.',  '2024-01-15'),
(1, 'Software License',    'Global Software Corp', '2024-02-20'),
(2, 'Marketing Services',  'Ad Agency Pro',        '2024-03-10'),
(3, 'Consulting Services', 'Business Growth Ltd.', '2024-04-01'),
(3, 'Training Program',    'EduTech Systems',      '2024-05-05'),
(4, 'Web Development',     'Creative Web Design',  '2024-06-12'),
(5, 'Cloud Storage',       'Data Secure Cloud',    '2024-07-25'),
(2, 'Graphic Design',      'Visual Arts Studio',   '2024-08-18'),
(1, 'Technical Support',   'Tech Solutions Inc.',  '2024-09-01'),
(6, 'Hardware Upgrade',    'Computer Parts Plus',  '2024-10-10');
GO

/* Give the read-only login from the AdventureWorks POC access to this DB too */
IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'claude_reader')
BEGIN
    IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'claude_reader')
        CREATE USER claude_reader FOR LOGIN claude_reader;
    ALTER ROLE db_datareader ADD MEMBER claude_reader;
    GRANT VIEW DEFINITION TO claude_reader;
END
GO

/* The course's reference queries, unchanged except for schema prefixes */
SELECT name FROM dbo.Customers WHERE id IN (SELECT DISTINCT customer_id FROM dbo.Orders);

SELECT company, COUNT(*) AS total_orders
FROM dbo.Orders GROUP BY company HAVING COUNT(*) > 1;

SELECT rd.id_number, rd.first_name, rd.last_name, un.email, rd.phone_number,
       rd.occupation, rd.gender, rd.is_18_or_older
FROM dbo.RegistrationDetails rd
JOIN dbo.UserNames un ON rd.id_number = un.id_number;
GO
