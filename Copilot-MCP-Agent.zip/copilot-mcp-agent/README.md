# MCP AI Agent demo, rebuilt for GitHub Copilot (Claude model)

This is the call's Claude Desktop setup converted to **VS Code + GitHub Copilot Agent mode**. The same MCP servers do the same jobs. You choose a Claude model in Copilot's model picker, and the workflows from the call are saved as reusable `/` commands.

## What the call's setup did

| Call file | Purpose |
|---|---|
| `mcp.json` | Claude Desktop config: Playwright, filesystem, Excel, REST API, MySQL |
| `Untitled.sql` | MySQL test database: `RegistrationDetails`, `UserNames`, `Customers`, `Orders` |
| `newdata.xlsx` | Where the agent saved credentials of users it registered |
| `EcomBasic.postman_collection.json` | Login and create-order API calls against the Let's Shop practice site |

The flow was: **read users from MySQL → register them on the site with Playwright → save credentials to Excel → log in and create an order through the REST API.**

## How each piece maps to Copilot

| Claude Desktop (call) | Copilot (this folder) | Why it changed |
|---|---|---|
| `mcpServers` in `claude_desktop_config.json` | `servers` in `.vscode/mcp.json` | VS Code's config format; each server also needs `"type": "stdio"` |
| `playwright` | `playwright`, same package | No change |
| `filesystem` server | **Dropped** | Copilot agent mode already reads and writes files in the open workspace |
| `excel-mcp-server` via **Smithery + API key** | `@negokaz/excel-mcp-server` run directly with `npx` | Same server with no third-party relay or key, which is easier to get approved at work |
| `rest-api` (`dkmaker-mcp-rest-api`) | Same, same environment variables | No change |
| `mysql` (Python, `uv`, Mac-only paths, root password) | `database` = **DBHub** in read-only mode | Works on Windows with Node only. Supports SQL Server **and** MySQL. No root account |
| Prompts typed into chat | `.github/prompts/*.prompt.md` → `/db-explore`, `/register-users`, `/api-order` | Repeatable and version-controlled; share with the team via git |
| (none) | `.github/copilot-instructions.md` | Standing rules Copilot reads on every request: which server does what, read-only, report format |

## Setup

1. **Database** (choose one):
   - **SQL Server** (recommended): run `sql/rsa-sqlserver.sql` in SSMS. It creates `RSAcademy` with the course's data and grants the `claude_reader` login from the AdventureWorks POC read access. Set the password in `config/dbhub.toml`.
   - **MySQL** (as in the call): run the original `Untitled.sql`, then switch `config/dbhub.toml` to Option B.
2. Open this folder in VS Code (**File → Open Folder**).
3. Open `.vscode/mcp.json` and click **Start** on each of the 4 servers. All should show as running. The first start downloads the packages.
4. Open Copilot Chat, choose **Agent** mode and a **Claude** model. Under the tools icon, check that `database`, `playwright`, `excel` and `rest-api` are enabled.

## Run it

| Command | What it does |
|---|---|
| `/db-explore` | Maps the tables and runs the course's join queries plus one harder one |
| `/register-users` | DB → Playwright registration (including an under-18 negative test) → writes `data/newdata.xlsx` |
| `/api-order` | Excel credentials → API login → create order → verify the order in the UI |

Run them in that order. Copilot asks before each tool call; choose **Allow in this session** to keep it moving.

## Notes and gotchas

- **The Excel tools need absolute paths.** The instructions file tells Copilot this, but if it passes `data/newdata.xlsx`, tell it to use the full path.
- **Close `newdata.xlsx` in Excel** before running `/register-users`. An open file is locked and the write fails.
- **Emails are made unique per run** (`...<timestamp>@example.com`), because the site rejects duplicates. The course's database passwords (`12345`) may fail the site's password rules; the prompt generates a compliant one and records it.
- **Credentials in the call's files:** the Postman collection contains the instructor's login, and `mcp.json` contains a MySQL root password. Don't reuse them. Register your own test user.
- **Work policy:** this uses public practice sites and fake data only. Before pointing it at internal apps or databases, check with your Copilot admin. Organizations can limit which MCP servers are allowed.
- **"spawn npx ENOENT" on Windows:** set `"command": "cmd"` and put `"/c", "npx",` at the start of that server's `args`.
- **MCP server logs:** **View → Output**, then choose the server in the dropdown.
